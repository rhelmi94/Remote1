import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email, To, Content
from flask import current_app
from itsdangerous import URLSafeTimedSerializer

def generate_reset_token(email):
    serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
    return serializer.dumps(email, salt='password-reset-salt')

def verify_reset_token(token, expiration=3600):
    serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
    try:
        email = serializer.loads(token, salt='password-reset-salt', max_age=expiration)
        return email
    except:
        return None

def send_password_reset_email(user_email, reset_url):
    sg = SendGridAPIClient(api_key=os.environ.get('MAIL_PASSWORD'))
    from_email = Email(os.environ.get('MAIL_USERNAME'))
    to_email = To(user_email)

    email_template = f"""
    <h1>Password Reset Request</h1>
    <p>To reset your password, click the following link:</p>
    <p><a href="{reset_url}">Reset Password</a></p>
    <p>If you did not request a password reset, please ignore this email.</p>
    <p>This link will expire in 1 hour.</p>
    """

    message = Mail(
        from_email=from_email,
        to_emails=to_email,
        subject='Password Reset Request',
        html_content=email_template
    )

    try:
        sg.send(message)
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False