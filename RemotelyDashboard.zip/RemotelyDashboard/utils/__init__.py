# This file marks the utils directory as a Python package
# Allowing imports like 'from utils.email_handler import send_password_reset_email'
