import logging
from flask_socketio import emit
from agent.remote_desktop import RemoteDesktopAgent

class RemoteDesktopService:
    def __init__(self):
        self._agents = {}
        self.logger = logging.getLogger(__name__)

    def start_streaming(self, device_id, user_id):
        """Start screen streaming for a device"""
        agent_key = f"{device_id}_{user_id}"
        if agent_key not in self._agents:
            self._agents[agent_key] = RemoteDesktopAgent()

        def emit_frame(frame_data):
            emit('screen_frame', frame_data, room=f'device_{device_id}')

        self._agents[agent_key].start_streaming(emit_frame)

    def stop_streaming(self, device_id):
        """Stop screen streaming for a device"""
        for agent_key in list(self._agents.keys()):
            if agent_key.startswith(f"{device_id}_"):
                self._agents[agent_key].stop_streaming()
                del self._agents[agent_key]

    def handle_mouse_event(self, device_id, event_data):
        """Handle mouse events - currently disabled in test mode"""
        self.logger.info(f"Mouse event received for device {device_id}: {event_data}")

    def handle_keyboard_event(self, device_id, event_data):
        """Handle keyboard events - currently disabled in test mode"""
        self.logger.info(f"Keyboard event received for device {device_id}: {event_data}")