from datetime import datetime
from typing import List, Optional, Dict
from flask_socketio import emit
import json

from app import db, socketio
from models import NotificationMessage, NotificationDelivery, NotificationPreference, User

class NotificationService:
    def __init__(self):
        self.supported_platforms = ['web', 'email', 'mobile', 'desktop']

    def create_notification(
        self,
        user_id: int,
        title: str,
        content: str,
        notification_type: str,
        priority: str = 'normal',
        source_type: Optional[str] = None,
        source_id: Optional[int] = None,
        metadata: Optional[Dict] = None,
        expires_at: Optional[datetime] = None
    ) -> NotificationMessage:
        """Create a new notification and schedule its delivery"""
        notification = NotificationMessage(
            user_id=user_id,
            title=title,
            content=content,
            notification_type=notification_type,
            priority=priority,
            source_type=source_type,
            source_id=source_id,
            meta_data=json.dumps(metadata) if metadata else None,
            expires_at=expires_at
        )
        db.session.add(notification)

        # Create delivery records based on user preferences
        preferences = NotificationPreference.query.filter_by(
            user_id=user_id,
            notification_type=notification_type,
            enabled=True
        ).all()

        for pref in preferences:
            if self._should_deliver(pref, notification):
                delivery = NotificationDelivery(
                    notification=notification,
                    platform=pref.platform,
                    status='pending'
                )
                db.session.add(delivery)

        db.session.commit()

        # Broadcast new notification to all connected clients
        self._broadcast_notification_update(notification, 'new_notification')
        return notification

    def _should_deliver(self, pref: NotificationPreference, notification: NotificationMessage) -> bool:
        """Check if notification should be delivered based on preferences"""
        if not pref.enabled:
            return False

        # Check priority threshold
        priority_levels = {'low': 0, 'normal': 1, 'high': 2, 'urgent': 3}
        if priority_levels[notification.priority] < priority_levels[pref.priority_threshold]:
            return False

        # Check quiet hours
        if pref.quiet_hours_start and pref.quiet_hours_end:
            current_time = datetime.now().time()
            if pref.quiet_hours_start <= current_time <= pref.quiet_hours_end:
                return False

        return True

    def _broadcast_notification_update(self, notification: NotificationMessage, event_type: str):
        """Broadcast notification updates to all connected clients"""
        notification_data = {
            'id': notification.id,
            'title': notification.title,
            'content': notification.content,
            'type': notification.notification_type,
            'priority': notification.priority,
            'created_at': notification.created_at.isoformat(),
            'is_read': notification.is_read,
            'meta_data': json.loads(notification.meta_data) if notification.meta_data else None,
            'event_type': event_type
        }

        # Emit to user's room
        socketio.emit('notification_sync', notification_data, room=f'user_{notification.user_id}')

    def mark_as_read(self, notification_id: int, user_id: int, platform: str = 'web') -> bool:
        """Mark a notification as read and sync across platforms"""
        notification = NotificationMessage.query.filter_by(
            id=notification_id,
            user_id=user_id
        ).first()

        if notification and not notification.is_read:
            notification.is_read = True
            notification.read_at = datetime.utcnow()

            # Update delivery status
            delivery = NotificationDelivery.query.filter_by(
                notification_id=notification_id,
                platform=platform
            ).first()
            if delivery:
                delivery.status = 'delivered'
                delivery.delivered_at = datetime.utcnow()

            db.session.commit()

            # Broadcast read status update
            self._broadcast_notification_update(notification, 'mark_read')
            return True
        return False

    def get_user_notifications(
        self,
        user_id: int,
        unread_only: bool = False,
        page: int = 1,
        per_page: int = 20
    ) -> List[NotificationMessage]:
        """Get user's notifications with pagination"""
        query = NotificationMessage.query.filter_by(user_id=user_id)
        if unread_only:
            query = query.filter_by(is_read=False)

        return query.order_by(NotificationMessage.created_at.desc())\
                   .paginate(page=page, per_page=per_page, error_out=False)

    def sync_notification_status(self, notification_id: int, platform: str, status: str) -> bool:
        """Sync notification delivery status across platforms"""
        delivery = NotificationDelivery.query.filter_by(
            notification_id=notification_id,
            platform=platform
        ).first()

        if delivery:
            delivery.status = status
            if status == 'delivered':
                delivery.delivered_at = datetime.utcnow()
            db.session.commit()

            # Broadcast delivery status update
            notification = NotificationMessage.query.get(notification_id)
            if notification:
                self._broadcast_notification_update(notification, 'delivery_status')
            return True
        return False

notification_service = NotificationService()