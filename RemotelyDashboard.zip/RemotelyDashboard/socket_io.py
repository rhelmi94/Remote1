# This file is deprecated and no longer used
# SocketIO initialization is now handled directly in app.py