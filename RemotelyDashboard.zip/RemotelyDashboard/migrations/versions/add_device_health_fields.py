"""add device health fields

Revision ID: add_device_health_fields
Revises: None
Create Date: 2025-02-26 21:30:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = 'add_device_health_fields'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # New health metrics columns with nullable=True to not affect existing data
    op.add_column('device', sa.Column('cpu_usage', sa.Float(), nullable=True))
    op.add_column('device', sa.Column('memory_usage', sa.Float(), nullable=True))
    op.add_column('device', sa.Column('disk_usage', sa.Float(), nullable=True))
    op.add_column('device', sa.Column('network_in_rate', sa.Float(), nullable=True))
    op.add_column('device', sa.Column('network_out_rate', sa.Float(), nullable=True))
    op.add_column('device', sa.Column('process_count', sa.Integer(), nullable=True))
    op.add_column('device', sa.Column('uptime', sa.Integer(), nullable=True))
    op.add_column('device', sa.Column('temperature', sa.Float(), nullable=True))

    # Update status column to include new states
    op.alter_column('device', 'status',
                    existing_type=sa.String(32),
                    type_=sa.String(32),
                    existing_nullable=True,
                    server_default='offline')

def downgrade():
    op.drop_column('device', 'temperature')
    op.drop_column('device', 'uptime')
    op.drop_column('device', 'process_count')
    op.drop_column('device', 'network_out_rate')
    op.drop_column('device', 'network_in_rate')
    op.drop_column('device', 'disk_usage')
    op.drop_column('device', 'memory_usage')
    op.drop_column('device', 'cpu_usage')
