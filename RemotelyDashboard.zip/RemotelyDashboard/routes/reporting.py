from flask import Blueprint, jsonify, request
from flask_login import login_required
from models import Device, SystemMetric, DeviceSession
from app import db
from datetime import datetime, timedelta

reports_bp = Blueprint('reports_bp', __name__)

@reports_bp.route('/api/reports/metrics')
@login_required
def get_device_metrics():
    """Get device metrics report"""
    days = request.args.get('days', 7, type=int)
    device_id = request.args.get('device_id', type=int)

    query = SystemMetric.query
    if device_id:
        query = query.filter_by(device_id=device_id)

    metrics = query.filter(
        SystemMetric.timestamp >= datetime.utcnow() - timedelta(days=days)
    ).order_by(SystemMetric.timestamp.desc()).all()

    return jsonify([{
        'id': metric.id,
        'timestamp': metric.timestamp.isoformat(),
        'device_id': metric.device_id,
        'cpu_percent': metric.cpu_percent,
        'memory_percent': metric.memory_percent,
        'disk_percent': metric.disk_percent,
        'network_in_bytes': metric.network_in_bytes,
        'network_out_bytes': metric.network_out_bytes,
        'process_count': metric.process_count,
        'temperature': metric.temperature
    } for metric in metrics])

@reports_bp.route('/api/reports/sessions')
@login_required
def get_device_sessions():
    """Get device session reports"""
    device_id = request.args.get('device_id', type=int)
    status = request.args.get('status', 'active')

    query = DeviceSession.query
    if device_id:
        query = query.filter_by(device_id=device_id)

    sessions = query.filter_by(status=status)\
        .order_by(DeviceSession.start_time.desc())\
        .limit(50).all()

    return jsonify([{
        'id': session.id,
        'device_id': session.device_id,
        'user_id': session.user_id,
        'start_time': session.start_time.isoformat(),
        'end_time': session.end_time.isoformat() if session.end_time else None,
        'session_type': session.session_type,
        'status': session.status
    } for session in sessions])

@reports_bp.route('/api/reports/devices')
@login_required
def get_device_status():
    """Get device status report"""
    devices = Device.query.all()

    return jsonify([{
        'id': device.id,
        'name': device.name,
        'platform': device.platform,
        'status': device.status,
        'health_score': device.health_score,
        'performance_rating': device.performance_rating,
        'cpu_health': device.cpu_health,
        'memory_health': device.memory_health,
        'disk_health': device.disk_health,
        'network_health': device.network_health,
        'last_health_check': device.last_health_check.isoformat() if device.last_health_check else None,
        'is_online': device.is_online
    } for device in devices])