from flask import Blueprint, request, jsonify
from app import db
from models import Device, DeviceGroup
from datetime import datetime

device_routes = Blueprint('devices', __name__)

@device_routes.route('/api/devices', methods=['GET'])
def get_devices():
    try:
        devices = Device.query.all()
        return jsonify({
            'status': 'success',
            'devices': [device.to_dict() for device in devices]
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@device_routes.route('/api/devices', methods=['POST'])
def add_device():
    try:
        data = request.get_json()

        # Create new device
        device = Device(
            name=data['name'],
            platform=data.get('platform', 'unknown'),
            group_id=data.get('group_id'),
            agent_version=data.get('agent_version', '1.0.0'),
            notes=data.get('notes', ''),
            status='offline',
            is_online=False,
            last_seen=datetime.utcnow()
        )

        db.session.add(device)
        db.session.commit()

        return jsonify({
            'status': 'success',
            'message': 'Device added successfully',
            'device': device.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400

@device_routes.route('/api/devices/<int:device_id>', methods=['GET'])
def get_device(device_id):
    device = Device.query.get_or_404(device_id)
    return jsonify(device.to_dict())

@device_routes.route('/api/devices/<int:device_id>', methods=['PUT'])
def update_device(device_id):
    try:
        device = Device.query.get_or_404(device_id)
        data = request.get_json()

        # Update fields
        for key, value in data.items():
            if hasattr(device, key):
                setattr(device, key, value)

        device.update_health_score()
        device.update_status()

        db.session.commit()

        return jsonify({
            'status': 'success',
            'message': 'Device updated successfully',
            'device': device.to_dict()
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400

@device_routes.route('/api/device-groups', methods=['GET'])
def get_device_groups():
    groups = DeviceGroup.query.all()
    return jsonify([group.to_dict() for group in groups])

@device_routes.route('/api/device-groups', methods=['POST'])
def create_device_group():
    try:
        data = request.get_json()
        group = DeviceGroup(
            name=data['name'],
            description=data.get('description', ''),
            parent_id=data.get('parent_id')
        )

        db.session.add(group)
        db.session.commit()

        return jsonify({
            'status': 'success',
            'message': 'Group created successfully',
            'group': group.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400