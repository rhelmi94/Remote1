from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from datetime import datetime
from services.notification_service import notification_service
from models import NotificationPreference, db

notification_bp = Blueprint('notifications', __name__)

@notification_bp.route('/notifications', methods=['GET'])
@login_required
def get_notifications():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    unread_only = request.args.get('unread', False, type=bool)
    
    notifications = notification_service.get_user_notifications(
        current_user.id,
        unread_only=unread_only,
        page=page,
        per_page=per_page
    )
    
    return jsonify({
        'notifications': [{
            'id': n.id,
            'title': n.title,
            'content': n.content,
            'type': n.notification_type,
            'priority': n.priority,
            'created_at': n.created_at.isoformat(),
            'is_read': n.is_read,
            'read_at': n.read_at.isoformat() if n.read_at else None
        } for n in notifications.items],
        'total': notifications.total,
        'pages': notifications.pages,
        'current_page': notifications.page
    })

@notification_bp.route('/notifications/<int:notification_id>/read', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    success = notification_service.mark_as_read(notification_id, current_user.id)
    return jsonify({'success': success})

@notification_bp.route('/notifications/preferences', methods=['GET', 'PUT'])
@login_required
def notification_preferences():
    if request.method == 'GET':
        preferences = NotificationPreference.query.filter_by(
            user_id=current_user.id
        ).all()
        return jsonify([{
            'id': p.id,
            'notification_type': p.notification_type,
            'platform': p.platform,
            'enabled': p.enabled,
            'quiet_hours_start': p.quiet_hours_start.strftime('%H:%M') if p.quiet_hours_start else None,
            'quiet_hours_end': p.quiet_hours_end.strftime('%H:%M') if p.quiet_hours_end else None,
            'frequency': p.frequency,
            'priority_threshold': p.priority_threshold
        } for p in preferences])
    
    data = request.get_json()
    pref = NotificationPreference.query.filter_by(
        user_id=current_user.id,
        notification_type=data['notification_type'],
        platform=data['platform']
    ).first()
    
    if not pref:
        pref = NotificationPreference(user_id=current_user.id)
    
    pref.notification_type = data['notification_type']
    pref.platform = data['platform']
    pref.enabled = data.get('enabled', True)
    pref.frequency = data.get('frequency', 'immediate')
    pref.priority_threshold = data.get('priority_threshold', 'normal')
    
    if 'quiet_hours_start' in data:
        pref.quiet_hours_start = datetime.strptime(data['quiet_hours_start'], '%H:%M').time()
    if 'quiet_hours_end' in data:
        pref.quiet_hours_end = datetime.strptime(data['quiet_hours_end'], '%H:%M').time()
    
    db.session.add(pref)
    db.session.commit()
    
    return jsonify({
        'id': pref.id,
        'notification_type': pref.notification_type,
        'platform': pref.platform,
        'enabled': pref.enabled,
        'quiet_hours_start': pref.quiet_hours_start.strftime('%H:%M') if pref.quiet_hours_start else None,
        'quiet_hours_end': pref.quiet_hours_end.strftime('%H:%M') if pref.quiet_hours_end else None,
        'frequency': pref.frequency,
        'priority_threshold': pref.priority_threshold
    })
