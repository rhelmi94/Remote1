from flask import Blueprint, render_template, jsonify, session
from flask_login import login_required, current_user
from flask_socketio import emit, join_room, leave_room
from app import socketio
from services.remote_desktop_service import RemoteDesktopService

remote_desktop_bp = Blueprint('remote_desktop', __name__)
remote_desktop_service = RemoteDesktopService()

@remote_desktop_bp.route('/remote/<int:device_id>')
@login_required
def remote_desktop(device_id):
    # Store the device_id in session for WebSocket handlers
    session['current_device_id'] = device_id
    return render_template('remote_desktop.html', device_id=device_id)

@socketio.on('connect')
@login_required
def handle_connect():
    device_id = session.get('current_device_id')
    if device_id:
        join_room(f'device_{device_id}')
        emit('connection_status', {'status': 'connected'})

@socketio.on('disconnect')
def handle_disconnect():
    if current_user.is_authenticated:
        device_id = session.get('current_device_id')
        if device_id:
            remote_desktop_service.stop_streaming(device_id)
            leave_room(f'device_{device_id}')

@socketio.on('start_streaming')
@login_required
def handle_start_streaming():
    device_id = session.get('current_device_id')
    if device_id:
        remote_desktop_service.start_streaming(device_id, current_user.id)

@socketio.on('stop_streaming')
@login_required
def handle_stop_streaming():
    device_id = session.get('current_device_id')
    if device_id:
        remote_desktop_service.stop_streaming(device_id)

@socketio.on('mouse_event')
@login_required
def handle_mouse_event(data):
    device_id = session.get('current_device_id')
    if device_id:
        remote_desktop_service.handle_mouse_event(device_id, data)

@socketio.on('keyboard_event')
@login_required
def handle_keyboard_event(data):
    device_id = session.get('current_device_id')
    if device_id:
        remote_desktop_service.handle_keyboard_event(device_id, data)