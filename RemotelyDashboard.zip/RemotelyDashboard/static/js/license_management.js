class LicenseManager {
    constructor() {
        this.initializeEventListeners();
        this.loadLicenses();
        this.updateInterval = setInterval(() => this.loadLicenses(), 30000);
    }

    initializeEventListeners() {
        // Create license
        document.getElementById('createLicense')?.addEventListener('click', () => {
            this.createLicense();
        });

        // Search functionality
        document.getElementById('licenseSearch')?.addEventListener('input', (e) => {
            this.filterLicenses(e.target.value);
        });

        // Revoke license
        document.getElementById('confirmRevoke')?.addEventListener('click', () => {
            this.revokeLicense();
        });

        // Download installer
        document.querySelectorAll('.download-installer').forEach(button => {
            button.addEventListener('click', (e) => {
                this.downloadInstaller(e.target.dataset.licenseKey);
            });
        });

        // Send installation email
        document.querySelectorAll('.send-email').forEach(button => {
            button.addEventListener('click', (e) => {
                this.sendInstallationEmail(e.target.dataset.licenseKey);
            });
        });
    }

    async loadLicenses() {
        try {
            const response = await fetch('/api/admin/licenses');
            const data = await response.json();

            this.updateStatistics(data.statistics);
            this.updateLicenseList(data.licenses);
        } catch (error) {
            console.error('Error loading licenses:', error);
            this.showAlert('error', 'Failed to load licenses');
        }
    }

    updateStatistics(stats) {
        document.getElementById('activeLicenses').textContent = stats.active;
        document.getElementById('expiringSoon').textContent = stats.expiring_soon;
        document.getElementById('revokedLicenses').textContent = stats.revoked;
        document.getElementById('totalDevices').textContent = stats.total_devices;
    }

    updateLicenseList(licenses) {
        const tbody = document.getElementById('licenseList');
        if (!tbody) return;

        tbody.innerHTML = licenses.map(license => `
            <tr>
                <td>
                    <span class="font-monospace">${license.license_key}</span>
                    <button class="btn btn-sm btn-link" onclick="navigator.clipboard.writeText('${license.license_key}')">
                        <i class="fas fa-copy"></i>
                    </button>
                </td>
                <td>
                    <div>${license.client_name}</div>
                    <small class="text-muted">${license.client_email}</small>
                </td>
                <td>
                    <span class="badge bg-${this.getTemplateBadgeColor(license.template)}">
                        ${license.template}
                    </span>
                </td>
                <td>
                    <span class="badge bg-${this.getStatusBadgeColor(license.status)}">
                        ${license.status}
                    </span>
                </td>
                <td>${new Date(license.created_at).toLocaleDateString()}</td>
                <td>${license.expires_at ? new Date(license.expires_at).toLocaleDateString() : 'Never'}</td>
                <td>${license.used_count} / ${license.max_uses || '∞'}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary download-installer" data-license-key="${license.license_key}">
                            <i class="fas fa-download"></i>
                        </button>
                        <button class="btn btn-outline-${license.is_active ? 'danger' : 'success'}"
                                onclick="licenseManager.${license.is_active ? 'showRevokeModal' : 'reactivateLicense'}('${license.license_key}')">
                            <i class="fas fa-${license.is_active ? 'ban' : 'redo'}"></i>
                        </button>
                        <button class="btn btn-outline-secondary send-email" data-license-key="${license.license_key}">
                            <i class="fas fa-envelope"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    async downloadInstaller(licenseKey) {
        try {
            window.location.href = `/api/installer/generate/${licenseKey}`;
            this.showAlert('success', 'Downloading installer...');
        } catch (error) {
            console.error('Error downloading installer:', error);
            this.showAlert('error', 'Failed to download installer');
        }
    }

    async sendInstallationEmail(licenseKey) {
        try {
            const response = await fetch(`/api/admin/licenses/${licenseKey}/send-email`, {
                method: 'POST'
            });

            if (!response.ok) throw new Error('Failed to send email');

            this.showAlert('success', 'Installation email sent successfully');
        } catch (error) {
            console.error('Error sending email:', error);
            this.showAlert('error', 'Failed to send installation email');
        }
    }

    async createLicense() {
        const form = document.getElementById('createLicenseForm');
        if (!form) return;

        const formData = new FormData(form);
        try {
            const response = await fetch('/api/admin/licenses', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(formData))
            });

            if (!response.ok) throw new Error('Failed to create license');

            const result = await response.json();
            this.showAlert('success', 'License created successfully');
            this.loadLicenses();
            bootstrap.Modal.getInstance(document.getElementById('createLicenseModal')).hide();
        } catch (error) {
            console.error('Error creating license:', error);
            this.showAlert('error', 'Failed to create license');
        }
    }

    async revokeLicense() {
        const licenseKey = document.getElementById('revokeLicenseForm').dataset.licenseKey;
        const reason = document.querySelector('#revokeLicenseForm textarea').value;

        try {
            const response = await fetch(`/api/admin/licenses/${licenseKey}/revoke`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ reason })
            });

            if (!response.ok) throw new Error('Failed to revoke license');

            this.showAlert('success', 'License revoked successfully');
            this.loadLicenses();
            bootstrap.Modal.getInstance(document.getElementById('revokeLicenseModal')).hide();
        } catch (error) {
            console.error('Error revoking license:', error);
            this.showAlert('error', 'Failed to revoke license');
        }
    }

    showRevokeModal(licenseKey) {
        const form = document.getElementById('revokeLicenseForm');
        form.dataset.licenseKey = licenseKey;
        new bootstrap.Modal(document.getElementById('revokeLicenseModal')).show();
    }

    async resendEmail(licenseKey) {
        try {
            const response = await fetch(`/api/admin/licenses/${licenseKey}/resend-email`, {
                method: 'POST'
            });

            if (!response.ok) throw new Error('Failed to resend email');

            this.showAlert('success', 'License email resent successfully');
        } catch (error) {
            console.error('Error resending email:', error);
            this.showAlert('error', 'Failed to resend email');
        }
    }

    getTemplateBadgeColor(template) {
        const colors = {
            basic: 'secondary',
            advanced: 'primary',
            network: 'info',
            security: 'success'
        };
        return colors[template] || 'secondary';
    }

    getStatusBadgeColor(status) {
        const colors = {
            active: 'success',
            expired: 'warning',
            revoked: 'danger',
            pending: 'info'
        };
        return colors[status] || 'secondary';
    }

    filterLicenses(searchTerm) {
        const rows = document.querySelectorAll('#licenseList tr');
        searchTerm = searchTerm.toLowerCase();

        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    }

    showAlert(type, message) {
        const toast = new bootstrap.Toast(document.getElementById('alertToast'));
        const toastBody = document.querySelector('#alertToast .toast-body');
        if (toastBody) {
            toastBody.textContent = message;
            toastBody.className = `toast-body text-${type}`;
            toast.show();
        }
    }

    cleanup() {
        clearInterval(this.updateInterval);
    }
}

// Initialize license manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.licenseManager = new LicenseManager();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    window.licenseManager?.cleanup();
});