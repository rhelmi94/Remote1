document.addEventListener('DOMContentLoaded', () => {
    const generateCodeForm = document.getElementById('generateCodeForm');

    // Template configuration toggles
    document.getElementById('monitorServices')?.addEventListener('change', e => {
        document.getElementById('serviceList').classList.toggle('d-none', !e.target.checked);
    });

    document.getElementById('monitorLogs')?.addEventListener('change', e => {
        document.getElementById('logList').classList.toggle('d-none', !e.target.checked);
    });

    document.getElementById('monitorDisk')?.addEventListener('change', e => {
        document.getElementById('diskList').classList.toggle('d-none', !e.target.checked);
    });

    // Add items to lists
    document.getElementById('addService')?.addEventListener('click', () => {
        const input = document.getElementById('serviceInput');
        if (input.value.trim()) {
            addListItem('selectedServices', input.value.trim());
            input.value = '';
        }
    });

    document.getElementById('addLog')?.addEventListener('click', () => {
        const input = document.getElementById('logInput');
        if (input.value.trim()) {
            addListItem('selectedLogs', input.value.trim());
            input.value = '';
        }
    });

    document.getElementById('addDisk')?.addEventListener('click', () => {
        const input = document.getElementById('diskInput');
        if (input.value.trim()) {
            addListItem('selectedDisks', input.value.trim());
            input.value = '';
        }
    });

    function addListItem(listId, value) {
        const list = document.getElementById(listId);
        const item = document.createElement('div');
        item.className = 'list-group-item d-flex justify-content-between align-items-center';
        item.innerHTML = `
            ${value}
            <button type="button" class="btn btn-sm btn-outline-danger remove-item">
                <i class="fas fa-times"></i>
            </button>
        `;
        item.querySelector('.remove-item').addEventListener('click', () => item.remove());
        list.appendChild(item);
    }

    if (generateCodeForm) {
        generateCodeForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            // Collect all configuration data
            const formData = {
                template: document.getElementById('codeTemplate').value,
                platform: document.getElementById('codePlatform').value,
                group_id: document.getElementById('codeGroup').value || null,
                expires_in: parseInt(document.getElementById('codeExpiry').value),
                max_uses: parseInt(document.getElementById('codeMaxUses').value),
                monitor_services: document.getElementById('monitorServices')?.checked || false,
                monitored_services: Array.from(document.getElementById('selectedServices')?.children || [])
                    .map(item => item.textContent.trim()),
                monitor_logs: document.getElementById('monitorLogs')?.checked || false,
                log_paths: Array.from(document.getElementById('selectedLogs')?.children || [])
                    .map(item => item.textContent.trim()),
                monitor_disk: document.getElementById('monitorDisk')?.checked || false,
                disk_paths: Array.from(document.getElementById('selectedDisks')?.children || [])
                    .map(item => item.textContent.trim())
            };

            try {
                const response = await fetch('/api/install-codes', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                const data = await response.json();

                if (response.ok) {
                    // Refresh the page to show new code
                    window.location.reload();
                } else {
                    alert(data.error || 'Failed to generate installation code');
                }
            } catch (error) {
                console.error('Error generating code:', error);
                alert('Failed to generate installation code');
            }
        });
    }

    // Copy installation link to clipboard
    document.querySelectorAll('.copy-link').forEach(button => {
        button.addEventListener('click', async () => {
            const url = button.dataset.url;
            try {
                await navigator.clipboard.writeText(url);
                const icon = button.querySelector('i');
                icon.className = 'fas fa-check';
                setTimeout(() => {
                    icon.className = 'fas fa-copy';
                }, 2000);
            } catch (err) {
                console.error('Failed to copy:', err);
                alert('Failed to copy installation link');
            }
        });
    });

    // Deactivate installation code
    document.querySelectorAll('.deactivate-code').forEach(button => {
        button.addEventListener('click', async () => {
            if (!confirm('Are you sure you want to deactivate this installation code?')) {
                return;
            }

            const codeId = button.dataset.code;
            try {
                const response = await fetch(`/api/install-codes/${codeId}/deactivate`, {
                    method: 'POST'
                });

                if (response.ok) {
                    window.location.reload();
                } else {
                    const data = await response.json();
                    alert(data.error || 'Failed to deactivate code');
                }
            } catch (error) {
                console.error('Error deactivating code:', error);
                alert('Failed to deactivate code');
            }
        });
    });
});