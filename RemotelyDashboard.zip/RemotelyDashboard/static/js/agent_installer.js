class AgentInstaller {
    constructor() {
        this.selectedTemplate = null;
        this.selectedMethod = null;
        this.selectedOS = null;
        this.installationToken = null;
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Installation option selection
        document.querySelectorAll('.installation-option').forEach(option => {
            option.addEventListener('click', (e) => {
                const method = e.currentTarget.dataset.method;
                this.selectInstallationMethod(method);
            });
        });

        // Template selection
        document.querySelectorAll('.template-card').forEach(template => {
            template.addEventListener('click', (e) => {
                const template = e.currentTarget.dataset.template;
                this.selectTemplate(template);
            });
        });

        // OS selection
        document.querySelectorAll('[data-os]').forEach(button => {
            button.addEventListener('click', (e) => {
                const os = e.currentTarget.dataset.os;
                this.selectOS(os);
            });
        });

        // Copy buttons
        document.querySelectorAll('.copy-command').forEach(button => {
            button.addEventListener('click', (e) => {
                const target = document.querySelector(e.currentTarget.dataset.clipboardTarget);
                if (target) {
                    navigator.clipboard.writeText(target.value);
                    this.showToast('Copied to clipboard');
                }
            });
        });

        // Email form submission
        document.getElementById('sendEmail')?.addEventListener('click', () => {
            this.sendEmailInstructions();
        });
    }

    selectInstallationMethod(method) {
        this.selectedMethod = method;
        document.querySelectorAll('.installation-option').forEach(option => {
            option.classList.toggle('border-primary', option.dataset.method === method);
        });

        if (method === 'email') {
            new bootstrap.Modal(document.getElementById('emailModal')).show();
        } else {
            document.getElementById('installationSteps').classList.remove('d-none');
        }

        this.updateSummary();
    }

    selectTemplate(template) {
        this.selectedTemplate = template;
        document.querySelectorAll('.template-card').forEach(card => {
            card.classList.toggle('selected', card.dataset.template === template);
        });
        this.updateSummary();
        this.generateInstallationToken();
    }

    selectOS(os) {
        this.selectedOS = os;
        document.querySelectorAll('[data-os]').forEach(button => {
            button.classList.toggle('active', button.dataset.os === os);
        });
        this.updateSummary();
        this.updateInstallationCommand();
    }

    async generateInstallationToken() {
        if (!this.selectedTemplate) return;

        try {
            const response = await fetch('/api/agent/generate-token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    template: this.selectedTemplate
                })
            });

            const data = await response.json();
            if (response.ok) {
                this.installationToken = data.token;
                document.getElementById('installToken').value = this.installationToken;
                this.updateInstallationCommand();
            } else {
                this.showToast('Failed to generate installation token', 'error');
            }
        } catch (error) {
            console.error('Error generating token:', error);
            this.showToast('Failed to generate installation token', 'error');
        }
    }

    updateInstallationCommand() {
        if (!this.selectedOS || !this.installationToken) return;

        const commands = {
            windows: `powershell -Command "iwr https://rmm.example.com/agent/windows -OutFile agent.exe; ./agent.exe install ${this.installationToken}"`,
            linux: `curl -sSL https://rmm.example.com/agent/linux | sudo bash -s -- ${this.installationToken}`,
            macos: `curl -sSL https://rmm.example.com/agent/macos | sudo bash -s -- ${this.installationToken}`
        };

        document.getElementById('installCommand').value = commands[this.selectedOS];
    }

    async sendEmailInstructions() {
        const form = document.getElementById('emailForm');
        const formData = new FormData(form);

        if (!this.selectedTemplate) {
            this.showToast('Please select a template first', 'error');
            return;
        }

        try {
            const response = await fetch('/api/agent/email-instructions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: formData.get('email'),
                    os: formData.get('os'),
                    template: this.selectedTemplate
                })
            });

            if (response.ok) {
                this.showToast('Installation instructions sent successfully');
                bootstrap.Modal.getInstance(document.getElementById('emailModal')).hide();
            } else {
                const data = await response.json();
                this.showToast(data.error || 'Failed to send instructions', 'error');
            }
        } catch (error) {
            console.error('Error sending instructions:', error);
            this.showToast('Failed to send instructions', 'error');
        }
    }

    updateSummary() {
        const summaryTemplate = document.getElementById('summaryTemplate');
        const summaryMethod = document.getElementById('summaryMethod');
        const summaryPlatform = document.getElementById('summaryPlatform');

        if (summaryTemplate) {
            summaryTemplate.textContent = this.selectedTemplate ? 
                this.selectedTemplate.charAt(0).toUpperCase() + this.selectedTemplate.slice(1) : 
                '-';
        }

        if (summaryMethod) {
            summaryMethod.textContent = this.selectedMethod ?
                this.selectedMethod.charAt(0).toUpperCase() + this.selectedMethod.slice(1) :
                '-';
        }

        if (summaryPlatform) {
            summaryPlatform.textContent = this.selectedOS ?
                this.selectedOS.charAt(0).toUpperCase() + this.selectedOS.slice(1) :
                '-';
        }
    }

    showToast(message, type = 'success') {
        const toast = new bootstrap.Toast(document.getElementById('alertToast'));
        const toastBody = document.querySelector('#alertToast .toast-body');
        if (toastBody) {
            toastBody.textContent = message;
            toastBody.className = `toast-body text-${type}`;
            toast.show();
        }
    }

    startVerification() {
        const progressBar = document.querySelector('.installation-progress .progress-bar');
        const statusDiv = document.getElementById('verificationStatus');
        let progress = 0;

        const interval = setInterval(() => {
            progress += 10;
            if (progressBar) progressBar.style.width = `${progress}%`;

            if (progress >= 100) {
                clearInterval(interval);
                if (statusDiv) {
                    statusDiv.innerHTML = `
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> Installation completed successfully
                        </div>
                    `;
                }
                document.getElementById('summaryStatus').innerHTML = `
                    <span class="badge bg-success">Installed</span>
                `;
            }
        }, 500);
    }
}

// Initialize agent installer when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.agentInstaller = new AgentInstaller();
});
