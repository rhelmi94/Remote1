document.addEventListener('DOMContentLoaded', () => {
    const groupForm = document.getElementById('groupForm');
    const groupList = document.getElementById('groupList');
    let currentGroupFilter = 'all';

    // Initialize groups
    fetchGroups();

    // Handle group creation
    groupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('groupName').value;
        const description = document.getElementById('groupDescription').value;

        try {
            const response = await fetch('/api/groups', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, description })
            });

            if (response.ok) {
                groupForm.reset();
                fetchGroups();
            }
        } catch (error) {
            console.error('Error creating group:', error);
        }
    });

    // Handle group filtering
    document.querySelectorAll('[data-group-id]').forEach(element => {
        element.addEventListener('click', (e) => {
            e.preventDefault();
            const groupId = e.target.dataset.groupId;
            currentGroupFilter = groupId;
            updateNetworkMap();
        });
    });

    async function fetchGroups() {
        try {
            const response = await fetch('/api/groups');
            const groups = await response.json();
            updateGroupList(groups);
        } catch (error) {
            console.error('Error fetching groups:', error);
        }
    }

    function updateGroupList(groups) {
        groupList.innerHTML = groups.map(group => `
            <div class="list-group-item">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">${group.name}</h6>
                        <small class="text-muted">${group.description || 'No description'}</small>
                    </div>
                    <div class="d-flex align-items-center">
                        <span class="badge bg-primary rounded-pill me-2">${group.device_count} devices</span>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                Actions
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" onclick="renameGroup(${group.id})">Rename</a></li>
                                <li><a class="dropdown-item" href="#" onclick="deleteGroup(${group.id})">Delete</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="mt-2 small">
                    <span class="me-2">Last Updated: ${new Date().toLocaleString()}</span>
                </div>
            </div>
        `).join('');
    }

    async function updateNetworkMap() {
        try {
            const url = currentGroupFilter === 'all' 
                ? '/api/network-connections'
                : `/api/network-connections?group_id=${currentGroupFilter}`;

            const response = await fetch(url);
            const connections = await response.json();
            networkMap.update(connections);
        } catch (error) {
            console.error('Error updating network map:', error);
        }
    }

    // Update groups every 30 seconds
    setInterval(fetchGroups, 30000);

    // Make functions globally available
    window.renameGroup = async (groupId) => {
        const newName = prompt('Enter new group name:');
        if (newName) {
            try {
                const response = await fetch(`/api/groups/${groupId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ name: newName })
                });
                if (response.ok) {
                    fetchGroups();
                }
            } catch (error) {
                console.error('Error renaming group:', error);
            }
        }
    };

    window.deleteGroup = async (groupId) => {
        if (confirm('Are you sure you want to delete this group?')) {
            try {
                const response = await fetch(`/api/groups/${groupId}`, {
                    method: 'DELETE'
                });
                if (response.ok) {
                    fetchGroups();
                }
            } catch (error) {
                console.error('Error deleting group:', error);
            }
        }
    };
});