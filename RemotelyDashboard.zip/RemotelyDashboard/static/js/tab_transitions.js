document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('[data-bs-toggle="tab"]');

    // Function to animate content
    const animateTabContent = (tabEl) => {
        const target = document.querySelector(tabEl.dataset.bsTarget);
        if (!target) return;

        // Add initial animation class
        target.style.opacity = '0';
        target.style.transform = 'translateX(-10px)';

        // Trigger reflow
        target.offsetHeight;

        // Add animation
        target.style.opacity = '1';
        target.style.transform = 'translateX(0)';
    };

    // Handle tab changes
    tabs.forEach(tab => {
        tab.addEventListener('shown.bs.tab', (event) => {
            animateTabContent(event.target);

            // Update URL hash without scrolling
            const hash = event.target.getAttribute('data-bs-target');
            if (history.pushState) {
                history.pushState(null, null, hash);
            }
        });

        // Add hover effect
        tab.addEventListener('mouseenter', () => {
            tab.style.transform = 'translateY(-2px)';
        });

        tab.addEventListener('mouseleave', () => {
            tab.style.transform = 'translateY(0)';
        });
    });

    // Add micro-interactions for dashboard elements
    const addMicroInteractions = () => {
        // Add loading animation to refresh buttons
        document.querySelectorAll('[data-feather="refresh-cw"]').forEach(icon => {
            const button = icon.closest('button');
            if (button) {
                button.addEventListener('click', () => {
                    icon.classList.add('icon-spin');
                    setTimeout(() => icon.classList.remove('icon-spin'), 1000);
                });
            }
        });

        // Add pulse effect to health status indicators
        document.querySelectorAll('.health-status').forEach(status => {
            status.addEventListener('mouseenter', () => {
                const icon = status.querySelector('.fas');
                if (icon) icon.style.transform = 'rotate(360deg)';
            });
        });

        // Animate progress bars on visibility
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const progressBar = entry.target;
                    const value = progressBar.getAttribute('aria-valuenow') || 0;
                    progressBar.style.width = '0%';
                    setTimeout(() => {
                        progressBar.style.width = `${value}%`;
                    }, 100);
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.progress-bar').forEach(bar => {
            observer.observe(bar);
        });

        // Add ripple effect to buttons
        document.querySelectorAll('.btn').forEach(button => {
            button.addEventListener('click', e => {
                const ripple = document.createElement('div');
                ripple.classList.add('ripple');
                button.appendChild(ripple);

                const rect = button.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size/2;
                const y = e.clientY - rect.top - size/2;

                ripple.style.width = ripple.style.height = `${size}px`;
                ripple.style.left = `${x}px`;
                ripple.style.top = `${y}px`;

                setTimeout(() => ripple.remove(), 600);
            });
        });
    };

    // Handle initial tab based on URL hash
    const hash = window.location.hash;
    if (hash) {
        const activeTab = document.querySelector(`[data-bs-target="${hash}"]`);
        if (activeTab) {
            const tab = new bootstrap.Tab(activeTab);
            tab.show();
        }
    }

    // Add smooth scrolling for better performance
    document.querySelectorAll('.nav-tabs').forEach(navTab => {
        navTab.style.scrollBehavior = 'smooth';
    });

    // Initialize micro-interactions
    addMicroInteractions();
});