class RemoteShell {
    constructor(deviceId) {
        this.deviceId = deviceId;
        this.socket = null;
        this.commandHistory = [];
        this.historyIndex = -1;
        this.fontSize = 14;
        this.isWordWrap = false;
        this.initializeUI();
        this.connectWebSocket();
    }

    initializeUI() {
        this.terminal = document.getElementById('terminalOutput');
        this.input = document.getElementById('commandInput');
        this.historyContainer = document.getElementById('commandHistory');
        this.statusIndicator = document.getElementById('connectionStatus');
        this.statusText = document.getElementById('statusText');

        // Command input handling
        this.input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendCommand();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.navigateHistory('up');
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.navigateHistory('down');
            }
        });

        // Quick commands
        document.querySelectorAll('[data-command]').forEach(button => {
            button.addEventListener('click', () => {
                this.input.value = button.dataset.command;
                this.sendCommand();
            });
        });

        // UI Controls
        document.getElementById('clearTerminal').addEventListener('click', () => this.clearTerminal());
        document.getElementById('downloadLog').addEventListener('click', () => this.downloadLog());
        document.getElementById('endSession').addEventListener('click', () => this.showEndSessionModal());
        document.getElementById('toggleWrap').addEventListener('click', () => this.toggleWordWrap());
        document.getElementById('increaseFontSize').addEventListener('click', () => this.changeFontSize(1));
        document.getElementById('decreaseFontSize').addEventListener('click', () => this.changeFontSize(-1));

        // Session end modal
        document.getElementById('confirmEndSession').addEventListener('click', () => {
            const saveLog = document.getElementById('saveLog').checked;
            if (saveLog) {
                this.downloadLog();
            }
            this.endSession();
        });
    }

    connectWebSocket() {
        this.socket = io(`/shell/${this.deviceId}`);

        this.socket.on('connect', () => {
            this.updateStatus('connected', 'Connected');
            this.appendOutput('Connected to remote shell\n', 'success');
        });

        this.socket.on('disconnect', () => {
            this.updateStatus('disconnected', 'Disconnected');
            this.appendOutput('Disconnected from remote shell\n', 'error');
        });

        this.socket.on('output', (data) => {
            this.appendOutput(data.output);
        });

        this.socket.on('error', (data) => {
            this.appendOutput(data.error + '\n', 'error');
        });
    }

    sendCommand() {
        const command = this.input.value.trim();
        if (!command) return;

        if (this.socket && this.socket.connected) {
            this.socket.emit('command', { command });
            this.appendOutput(`$ ${command}\n`);
            this.addToHistory(command);
            this.input.value = '';
            this.historyIndex = -1;
        } else {
            this.appendOutput('Not connected to remote shell\n', 'error');
        }
    }

    appendOutput(text, className = '') {
        const line = document.createElement('div');
        line.className = `output-line ${className}`;
        line.textContent = text;
        this.terminal.appendChild(line);
        this.terminal.scrollTop = this.terminal.scrollHeight;
    }

    addToHistory(command) {
        this.commandHistory.unshift(command);
        if (this.commandHistory.length > 50) {
            this.commandHistory.pop();
        }
        this.updateHistoryUI();
    }

    updateHistoryUI() {
        this.historyContainer.innerHTML = '';
        this.commandHistory.forEach(cmd => {
            const entry = document.createElement('a');
            entry.className = 'list-group-item list-group-item-action command-entry';
            entry.textContent = cmd;
            entry.addEventListener('click', () => {
                this.input.value = cmd;
                this.input.focus();
            });
            this.historyContainer.appendChild(entry);
        });
    }

    navigateHistory(direction) {
        if (direction === 'up' && this.historyIndex < this.commandHistory.length - 1) {
            this.historyIndex++;
        } else if (direction === 'down' && this.historyIndex >= 0) {
            this.historyIndex--;
        }

        if (this.historyIndex >= 0 && this.historyIndex < this.commandHistory.length) {
            this.input.value = this.commandHistory[this.historyIndex];
        } else if (this.historyIndex === -1) {
            this.input.value = '';
        }
    }

    updateStatus(status, text) {
        this.statusIndicator.className = `status-indicator ${status}`;
        this.statusText.textContent = text;
    }

    clearTerminal() {
        this.terminal.innerHTML = '';
    }

    async downloadLog() {
        const text = this.terminal.innerText;
        const blob = new Blob([text], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `remote_shell_log_${new Date().toISOString()}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    showEndSessionModal() {
        const modal = new bootstrap.Modal(document.getElementById('endSessionModal'));
        modal.show();
    }

    endSession() {
        if (this.socket) {
            this.socket.disconnect();
        }
        window.location.href = `/device/${this.deviceId}/details`;
    }

    toggleWordWrap() {
        this.isWordWrap = !this.isWordWrap;
        this.terminal.style.whiteSpace = this.isWordWrap ? 'pre-wrap' : 'pre';
        document.getElementById('toggleWrap').classList.toggle('active');
    }

    changeFontSize(delta) {
        this.fontSize = Math.max(10, Math.min(20, this.fontSize + delta));
        this.terminal.style.fontSize = `${this.fontSize}px`;
        this.input.style.fontSize = `${this.fontSize}px`;
    }
}

// Initialize the remote shell when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const deviceId = new URLSearchParams(window.location.search).get('device_id');
    if (deviceId) {
        window.remoteShell = new RemoteShell(deviceId);
    }
});
