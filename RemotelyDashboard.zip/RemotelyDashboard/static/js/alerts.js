class AlertManager {
    constructor() {
        this.socket = null;
        this.initializeWebSocket();
        this.initializeEventListeners();
        this.updateCounters();
    }

    initializeWebSocket() {
        this.socket = io('/alerts');
        
        this.socket.on('connect', () => {
            console.log('Connected to alert system');
        });

        this.socket.on('new_alert', (data) => {
            this.handleNewAlert(data);
        });

        this.socket.on('alert_resolved', (data) => {
            this.handleResolvedAlert(data);
        });

        this.socket.on('counter_update', (data) => {
            this.updateCounters(data);
        });
    }

    initializeEventListeners() {
        // Alert Rule Form
        document.getElementById('alertRuleForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveAlertRule();
        });

        // Target Type Selection
        document.querySelector('select[name="target_type"]')?.addEventListener('change', (e) => {
            this.updateTargetSelection(e.target.value);
        });

        // Edit/Delete Rule Buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.edit-rule')) {
                const ruleId = e.target.closest('.edit-rule').dataset.ruleId;
                this.editRule(ruleId);
            } else if (e.target.closest('.delete-rule')) {
                const ruleId = e.target.closest('.delete-rule').dataset.ruleId;
                this.deleteRule(ruleId);
            }
        });

        // Refresh Button
        document.getElementById('refreshAlerts')?.addEventListener('click', () => {
            this.refreshAlerts();
        });

        // Custom Check Configuration
        document.querySelector('select[name="metric_type"]')?.addEventListener('change', (e) => {
            this.toggleCustomCheckOptions(e.target.value === 'custom');
        });
    }

    async saveAlertRule() {
        const form = document.getElementById('alertRuleForm');
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);

        // Format notification channels
        data.notification_channels = Array.from(
            form.querySelectorAll('input[name="notification_channels"]:checked')
        ).map(input => input.value);

        try {
            const response = await fetch('/api/alerts/rules', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error('Failed to create alert rule');
            }

            const result = await response.json();
            this.addRuleToTable(result);
            bootstrap.Modal.getInstance(document.getElementById('createAlertModal')).hide();
            form.reset();

        } catch (error) {
            console.error('Error saving alert rule:', error);
            alert('Failed to create alert rule. Please try again.');
        }
    }

    async updateTargetSelection(targetType) {
        const targetSelection = document.getElementById('targetSelection');
        const targetSelect = targetSelection.querySelector('select');

        if (targetType === 'all') {
            targetSelection.style.display = 'none';
            return;
        }

        targetSelection.style.display = 'block';
        targetSelect.innerHTML = '<option value="">Loading...</option>';

        try {
            const response = await fetch(`/api/alerts/targets/${targetType}`);
            const targets = await response.json();

            targetSelect.innerHTML = targets.map(target => 
                `<option value="${target.id}">${target.name}</option>`
            ).join('');

        } catch (error) {
            console.error('Error loading targets:', error);
            targetSelect.innerHTML = '<option value="">Error loading targets</option>';
        }
    }

    async editRule(ruleId) {
        try {
            const response = await fetch(`/api/alerts/rules/${ruleId}`);
            const rule = await response.json();

            // Populate form with rule data
            const form = document.getElementById('alertRuleForm');
            Object.entries(rule).forEach(([key, value]) => {
                const input = form.querySelector(`[name="${key}"]`);
                if (input) {
                    if (input.type === 'checkbox') {
                        input.checked = value;
                    } else {
                        input.value = value;
                    }
                }
            });

            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('createAlertModal'));
            modal.show();

        } catch (error) {
            console.error('Error loading alert rule:', error);
            alert('Failed to load alert rule');
        }
    }

    async deleteRule(ruleId) {
        if (!confirm('Are you sure you want to delete this alert rule?')) {
            return;
        }

        try {
            const response = await fetch(`/api/alerts/rules/${ruleId}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Failed to delete alert rule');
            }

            document.querySelector(`tr[data-rule-id="${ruleId}"]`)?.remove();

        } catch (error) {
            console.error('Error deleting alert rule:', error);
            alert('Failed to delete alert rule');
        }
    }

    handleNewAlert(alert) {
        const alertsList = document.getElementById('activeAlertsList');
        const alertElement = document.createElement('div');
        alertElement.className = `alert alert-${alert.severity} alert-dismissible fade show`;
        alertElement.setAttribute('role', 'alert');
        alertElement.innerHTML = `
            <strong>${alert.device_name}:</strong> ${alert.details}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        alertsList.insertBefore(alertElement, alertsList.firstChild);

        // Update counters
        this.updateCounters();
    }

    handleResolvedAlert(alert) {
        // Remove alert from active alerts list if present
        document.querySelector(`[data-alert-id="${alert.id}"]`)?.remove();
        
        // Update counters
        this.updateCounters();
    }

    updateCounters(data) {
        if (data) {
            document.getElementById('criticalCount').textContent = data.critical || 0;
            document.getElementById('warningCount').textContent = data.warning || 0;
            document.getElementById('ruleCount').textContent = data.total_rules || 0;
            document.getElementById('healthyCount').textContent = data.healthy_devices || 0;
        } else {
            this.refreshCounters();
        }
    }

    async refreshCounters() {
        try {
            const response = await fetch('/api/alerts/counters');
            const data = await response.json();
            this.updateCounters(data);
        } catch (error) {
            console.error('Error refreshing counters:', error);
        }
    }

    async refreshAlerts() {
        try {
            const response = await fetch('/api/alerts/active');
            const alerts = await response.json();
            
            const alertsList = document.getElementById('activeAlertsList');
            alertsList.innerHTML = alerts.map(alert => `
                <div class="alert alert-${alert.severity} alert-dismissible fade show" role="alert">
                    <strong>${alert.device_name}:</strong> ${alert.details}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `).join('');
        } catch (error) {
            console.error('Error refreshing alerts:', error);
        }
    }

    addRuleToTable(rule) {
        const tbody = document.getElementById('alertRulesList');
        const row = document.createElement('tr');
        row.dataset.ruleId = rule.id;
        row.innerHTML = `
            <td>${rule.name}</td>
            <td>${rule.metric_type}</td>
            <td>${rule.condition} ${rule.threshold}</td>
            <td>
                <span class="badge bg-success">Active</span>
            </td>
            <td>Never</td>
            <td>
                <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary edit-rule" 
                            data-rule-id="${rule.id}"
                            title="Edit Rule">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-outline-danger delete-rule"
                            data-rule-id="${rule.id}"
                            title="Delete Rule">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        tbody.insertBefore(row, tbody.firstChild);
    }

    toggleCustomCheckOptions(show) {
        const customCheckOptions = document.getElementById('customCheckOptions');
        if (customCheckOptions) {
            customCheckOptions.style.display = show ? 'block' : 'none';
        }
    }
}

// Initialize alert manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.alertManager = new AlertManager();
});
