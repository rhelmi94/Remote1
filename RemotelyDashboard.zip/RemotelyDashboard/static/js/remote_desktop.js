document.addEventListener('DOMContentLoaded', function() {
    const socket = io();
    const canvas = document.getElementById('remoteCanvas');
    const ctx = canvas.getContext('2d');
    let isControlEnabled = false;
    let isRecording = false;
    let recordingStartTime = null;
    let recordingInterval = null;
    let isConnected = false;
    let currentQuality = 'high';
    let autoSyncClipboard = false;

    // Connect to WebSocket
    socket.on('connect', () => {
        console.log('Connected to server');
        isConnected = true;
        updateConnectionStatus(true);
        socket.emit('start_streaming');
    });

    socket.on('disconnect', () => {
        isConnected = false;
        updateConnectionStatus(false);
    });

    // Handle screen frames
    socket.on('screen_frame', (data) => {
        const img = new Image();
        img.onload = () => {
            canvas.width = data.width;
            canvas.height = data.height;
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            updatePerformanceStats(data.stats);
        };
        img.src = 'data:image/jpeg;base64,' + data.image;
    });

    // Handle clipboard sync
    socket.on('clipboard_update', (data) => {
        if (autoSyncClipboard) {
            document.getElementById('remoteClipboard').value = data.content;
            if (navigator.clipboard) {
                navigator.clipboard.writeText(data.content);
            }
        }
    });

    // Control button
    document.getElementById('controlBtn').addEventListener('click', function() {
        isControlEnabled = !isControlEnabled;
        this.classList.toggle('active');
        canvas.style.cursor = isControlEnabled ? 'crosshair' : 'default';
    });

    // Mouse events
    canvas.addEventListener('mousemove', (e) => {
        if (!isControlEnabled) return;

        const rect = canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) * (canvas.width / rect.width);
        const y = (e.clientY - rect.top) * (canvas.height / rect.height);

        socket.emit('mouse_event', {
            type: 'move',
            x: x,
            y: y
        });
    });

    canvas.addEventListener('mousedown', (e) => {
        if (!isControlEnabled) return;

        const rect = canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) * (canvas.width / rect.width);
        const y = (e.clientY - rect.top) * (canvas.height / rect.height);

        socket.emit('mouse_event', {
            type: 'down',
            button: e.button,
            x: x,
            y: y
        });
    });

    canvas.addEventListener('mouseup', (e) => {
        if (!isControlEnabled) return;

        const rect = canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) * (canvas.width / rect.width);
        const y = (e.clientY - rect.top) * (canvas.height / rect.height);

        socket.emit('mouse_event', {
            type: 'up',
            button: e.button,
            x: x,
            y: y
        });
    });

    // Keyboard events
    document.addEventListener('keydown', (e) => {
        if (!isControlEnabled) return;
        socket.emit('keyboard_event', {
            type: 'keydown',
            key: e.key,
            keyCode: e.keyCode,
            modifiers: {
                ctrl: e.ctrlKey,
                alt: e.altKey,
                shift: e.shiftKey,
                meta: e.metaKey
            }
        });
    });

    document.addEventListener('keyup', (e) => {
        if (!isControlEnabled) return;
        socket.emit('keyboard_event', {
            type: 'keyup',
            key: e.key,
            keyCode: e.keyCode,
            modifiers: {
                ctrl: e.ctrlKey,
                alt: e.altKey,
                shift: e.shiftKey,
                meta: e.metaKey
            }
        });
    });

    // Screenshot functionality
    document.getElementById('screenshotBtn').addEventListener('click', () => {
        const dataUrl = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.download = `screenshot-${new Date().toISOString()}.png`;
        link.href = dataUrl;
        link.click();
    });

    // Recording functionality
    document.getElementById('recordBtn').addEventListener('click', () => {
        const modal = new bootstrap.Modal(document.getElementById('recordingModal'));
        modal.show();
    });

    document.getElementById('startRecording').addEventListener('click', () => {
        if (!isRecording) {
            startRecording();
        } else {
            stopRecording();
        }
    });

    // Quality control
    document.querySelectorAll('[data-quality]').forEach(option => {
        option.addEventListener('click', (e) => {
            currentQuality = e.target.dataset.quality;
            socket.emit('set_quality', { quality: currentQuality });
            document.getElementById('currentQuality').textContent = currentQuality;
        });
    });

    // Monitor selection
    document.querySelectorAll('[data-monitor]').forEach(button => {
        button.addEventListener('click', (e) => {
            socket.emit('select_monitor', { monitor: e.target.dataset.monitor });
        });
    });

    // Clipboard sync
    document.getElementById('clipboardBtn').addEventListener('click', () => {
        const modal = new bootstrap.Modal(document.getElementById('clipboardModal'));
        modal.show();
    });

    document.getElementById('autoSync').addEventListener('change', (e) => {
        autoSyncClipboard = e.target.checked;
    });

    document.getElementById('syncClipboard').addEventListener('click', () => {
        const content = document.getElementById('localClipboard').value;
        socket.emit('clipboard_sync', { content });
    });

    // Fullscreen functionality
    document.getElementById('fullscreenBtn').addEventListener('click', () => {
        if (canvas.requestFullscreen) {
            canvas.requestFullscreen();
        }
    });

    // Helper functions
    function updateConnectionStatus(connected) {
        const statusEl = document.getElementById('connectionStatus');
        statusEl.innerHTML = connected ?
            '<i class="fas fa-circle text-success"></i> Connected' :
            '<i class="fas fa-circle text-danger"></i> Disconnected';
    }

    function updatePerformanceStats(stats) {
        document.getElementById('currentFps').textContent = stats.fps;
        document.getElementById('latency').textContent = `Latency: ${stats.latency}ms`;
        document.getElementById('bandwidth').textContent = `Bandwidth: ${formatBytes(stats.bandwidth)}/s`;
        document.getElementById('resolution').textContent = `Resolution: ${stats.width}x${stats.height}`;
    }

    function formatBytes(bytes) {
        const sizes = ['B', 'KB', 'MB', 'GB'];
        if (bytes === 0) return '0 B';
        const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

    function startRecording() {
        isRecording = true;
        recordingStartTime = Date.now();
        document.getElementById('recordingStats').classList.remove('d-none');
        document.getElementById('startRecording').textContent = 'Stop Recording';

        socket.emit('start_recording', {
            quality: document.getElementById('recordingQuality').value,
            audio: document.getElementById('recordAudio').checked
        });

        recordingInterval = setInterval(updateRecordingStats, 1000);
    }

    function stopRecording() {
        isRecording = false;
        clearInterval(recordingInterval);
        document.getElementById('startRecording').textContent = 'Start Recording';
        socket.emit('stop_recording');
    }

    function updateRecordingStats() {
        const duration = Math.floor((Date.now() - recordingStartTime) / 1000);
        const hours = Math.floor(duration / 3600);
        const minutes = Math.floor((duration % 3600) / 60);
        const seconds = duration % 60;

        document.getElementById('recordingTime').textContent =
            `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        if (isConnected) {
            socket.emit('stop_streaming');
            if (isRecording) {
                stopRecording();
            }
            socket.disconnect();
        }
    });
});