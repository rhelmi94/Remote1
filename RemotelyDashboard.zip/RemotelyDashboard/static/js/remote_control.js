document.addEventListener('DOMContentLoaded', () => {
    let socket = null;
    let currentSession = null;
    const remoteScreen = document.getElementById('remoteScreen');
    const startButton = document.getElementById('startRemote');
    const pauseButton = document.getElementById('pauseRemote');
    const stopButton = document.getElementById('stopRemote');
    const chatMessages = document.getElementById('chatMessages');
    const chatInput = document.getElementById('chatInput');
    const sendMessageBtn = document.getElementById('sendMessage');
    const terminalOutput = document.querySelector('.terminal-output');
    const terminalContainer = document.getElementById('terminal-container');
    const commandInput = document.getElementById('command-input');
    const sendCommandBtn = document.getElementById('send-command');
    const scriptForm = document.getElementById('scriptForm');


    // Remote Control Session Management
    async function startRemoteSession() {
        try {
            const deviceId = getDeviceId();
            const response = await fetch(`/api/device/${deviceId}/remote-sessions`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    type: 'remote_control'
                })
            });

            const data = await response.json();
            if (response.ok) {
                currentSession = data;
                initializeWebSocket(data.connection_id);
                updateUIState('connected');
            } else {
                showError('Failed to start remote session');
            }
        } catch (error) {
            console.error('Error starting remote session:', error);
            showError('Failed to start remote session');
        }
    }

    function initializeWebSocket(connectionId) {
        socket = io(`/remote/${connectionId}`);

        socket.on('connect', () => {
            console.log('WebSocket connected');
            updateConnectionStatus('Connected to remote device');
        });

        socket.on('disconnect', () => {
            console.log('WebSocket disconnected');
            updateConnectionStatus('Disconnected from remote device');
            updateUIState('disconnected');
        });

        socket.on('screen_data', (data) => {
            updateRemoteScreen(data);
        });

        socket.on('chat_message', (data) => {
            appendChatMessage(data.sender, data.message);
        });

        socket.on('metrics_update', (data) => {
            updateMetrics(data);
        });
    }

    function updateRemoteScreen(data) {
        if (remoteScreen) {
            // Update screen content based on received data
            // This could be an image, video stream, or other display format
            remoteScreen.innerHTML = `<img src="data:image/jpeg;base64,${data.screen}" alt="Remote Screen">`;
        }
    }

    function updateUIState(state) {
        if (startButton) startButton.disabled = state === 'connected';
        if (pauseButton) pauseButton.disabled = state !== 'connected';
        if (stopButton) stopButton.disabled = state !== 'connected';
    }

    function updateConnectionStatus(message) {
        const statusElem = document.getElementById('connectionStatus');
        if (statusElem) {
            statusElem.textContent = message;
        }
    }

    function appendChatMessage(sender, message) {
        if (chatMessages) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `chat-message ${sender === 'me' ? 'sent' : 'received'}`;
            messageDiv.innerHTML = `
                <small class="sender">${sender}</small>
                <div class="message-content">${message}</div>
                <small class="time">${new Date().toLocaleTimeString()}</small>
            `;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }

    // Event Listeners
    if (startButton) {
        startButton.addEventListener('click', startRemoteSession);
    }

    if (stopButton) {
        stopButton.addEventListener('click', async () => {
            if (currentSession) {
                try {
                    await fetch(`/api/device/${getDeviceId()}/remote-sessions/${currentSession.session_id}`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            status: 'ended'
                        })
                    });

                    if (socket) {
                        socket.disconnect();
                    }
                    updateUIState('disconnected');
                } catch (error) {
                    console.error('Error ending session:', error);
                }
            }
        });
    }

    if (sendMessageBtn && chatInput) {
        sendMessageBtn.addEventListener('click', () => {
            const message = chatInput.value.trim();
            if (message && socket) {
                socket.emit('chat_message', { message });
                appendChatMessage('me', message);
                chatInput.value = '';
            }
        });

        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessageBtn.click();
            }
        });
    }

    // Quick Actions
    document.getElementById('sendCtrlAltDel')?.addEventListener('click', () => {
        if (socket) {
            socket.emit('send_keys', { keys: 'ctrl+alt+del' });
        }
    });

    document.getElementById('lockScreen')?.addEventListener('click', () => {
        if (socket) {
            socket.emit('lock_screen');
        }
    });

    document.getElementById('restart')?.addEventListener('click', () => {
        if (socket && confirm('Are you sure you want to restart the remote device?')) {
            socket.emit('restart_device');
        }
    });


    // Remote Session Management (Original Code)
    document.querySelectorAll('.start-session').forEach(button => {
        button.addEventListener('click', async () => {
            const sessionType = button.dataset.type;
            const deviceId = getSelectedDeviceId(); 

            try {
                const response = await fetch('/api/remote/sessions/start', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        device_id: deviceId,
                        session_type: sessionType
                    })
                });

                const data = await response.json();

                if (response.ok) {
                    currentSession = data;
                    terminalContainer.classList.remove('d-none');
                    appendToTerminal(`Started ${sessionType} session...`);
                } else {
                    alert(data.error || 'Failed to start session');
                }
            } catch (error) {
                console.error('Error starting session:', error);
                alert('Failed to start session');
            }
        });
    });

    // Command Execution (Original Code)
    if (sendCommandBtn) {
        sendCommandBtn.addEventListener('click', async () => {
            const command = commandInput.value.trim();
            if (!command || !currentSession) return;

            try {
                const response = await fetch('/api/remote/execute', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        session_id: currentSession.session_id,
                        device_id: getSelectedDeviceId(),
                        command: command
                    })
                });

                const data = await response.json();

                if (response.ok) {
                    appendToTerminal(`> ${command}`);
                    commandInput.value = '';
                } else {
                    alert(data.error || 'Failed to execute command');
                }
            } catch (error) {
                console.error('Error executing command:', error);
                alert('Failed to execute command');
            }
        });
    }

    // Script Management (Original Code)
    if (scriptForm) {
        scriptForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const formData = {
                name: document.getElementById('scriptName').value,
                content: document.getElementById('scriptContent').value,
                script_type: document.getElementById('scriptType').value,
                target_platform: getSelectedDevicePlatform() 
            };

            try {
                const response = await fetch('/api/scripts', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                const data = await response.json();

                if (response.ok) {
                    alert('Script saved successfully');
                    loadSavedScripts(); 
                    scriptForm.reset();
                } else {
                    alert(data.error || 'Failed to save script');
                }
            } catch (error) {
                console.error('Error saving script:', error);
                alert('Failed to save script');
            }
        });
    }

    // Helper Functions (Original Code)
    function appendToTerminal(text) {
        if (terminalOutput) {
            const line = document.createElement('div');
            line.textContent = text;
            terminalOutput.appendChild(line);
            terminalOutput.scrollTop = terminalOutput.scrollHeight;
        }
    }

    function getSelectedDeviceId() {
        // Get the device ID from the URL or data attribute
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('device_id');
    }

    function getSelectedDevicePlatform() {
        // Get the platform from a data attribute or element
        const deviceInfo = document.querySelector('[data-device-platform]');
        return deviceInfo ? deviceInfo.dataset.devicePlatform : null;
    }

    // Load saved scripts on page load (Original Code)
    async function loadSavedScripts() {
        try {
            const response = await fetch('/api/scripts');
            const scripts = await response.json();

            const scriptsList = document.querySelector('#savedScripts .list-group');
            if (scriptsList) {
                scriptsList.innerHTML = scripts.map(script => `
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="mb-1">${script.name}</h6>
                            <button class="btn btn-sm btn-primary execute-script" data-script-id="${script.id}">
                                Execute
                            </button>
                        </div>
                        <small class="text-muted">Type: ${script.script_type}, Created: ${new Date(script.created_at).toLocaleString()}</small>
                    </div>
                `).join('');

                // Add event listeners for execute buttons
                document.querySelectorAll('.execute-script').forEach(button => {
                    button.addEventListener('click', async () => {
                        const scriptId = button.dataset.scriptId;
                        try {
                            const response = await fetch(`/api/scripts/${scriptId}/execute`, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    device_id: getSelectedDeviceId()
                                })
                            });

                            const data = await response.json();

                            if (response.ok) {
                                alert('Script execution started');
                            } else {
                                alert(data.error || 'Failed to execute script');
                            }
                        } catch (error) {
                            console.error('Error executing script:', error);
                            alert('Failed to execute script');
                        }
                    });
                });
            }
        } catch (error) {
            console.error('Error loading scripts:', error);
        }
    }

    // Initial load of saved scripts (Original Code)
    loadSavedScripts();

    // Helper Functions (New Code)
    function getDeviceId() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('device_id');
    }

    function showError(message) {
        // Show error in modal
        const modal = new bootstrap.Modal(document.getElementById('connectionModal'));
        const statusElement = document.getElementById('connectionStatus');
        if (statusElement) {
            statusElement.textContent = message;
        }
        modal.show();
    }

    function updateMetrics(data) {
        // Update performance metrics on the UI
        const metricsElements = {
            cpu: document.getElementById('cpuUsage'),
            memory: document.getElementById('memoryUsage'),
            disk: document.getElementById('diskUsage'),
            network: document.getElementById('networkUsage')
        };

        if (metricsElements.cpu) metricsElements.cpu.textContent = `${data.cpu_usage}%`;
        if (metricsElements.memory) metricsElements.memory.textContent = `${data.memory_usage}%`;
        if (metricsElements.disk) metricsElements.disk.textContent = `${data.disk_usage}%`;
        if (metricsElements.network) {
            metricsElements.network.textContent = 
                `In: ${formatBytes(data.network_in_rate)}/s Out: ${formatBytes(data.network_out_rate)}/s`;
        }
    }

    function formatBytes(bytes) {
        const units = ['B', 'KB', 'MB', 'GB'];
        let value = bytes;
        let unitIndex = 0;
        while (value >= 1024 && unitIndex < units.length - 1) {
            value /= 1024;
            unitIndex++;
        }
        return `${value.toFixed(1)} ${units[unitIndex]}`;
    }
});