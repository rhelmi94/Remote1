let cpuChart, memoryChart, diskChart, networkChart;
let lastNetworkIn = 0;
let lastNetworkOut = 0;
let lastDiskRead = 0;
let lastDiskWrite = 0;
let updateInterval = null;
let selectedDevices = new Set();
let chartType = 'line';

function initializeCharts() {
    const chartConfig = {
        line: {
            tension: 0.1,
            fill: false
        },
        area: {
            tension: 0.1,
            fill: true
        },
        bar: {
            tension: 0
        }
    };

    const commonOptions = {
        responsive: true,
        animation: { duration: 750 },
        scales: {
            y: {
                beginAtZero: true,
                title: { display: true }
            }
        },
        plugins: {
            title: { display: true }
        }
    };

    // Initialize CPU Chart
    cpuChart = new Chart(document.getElementById('cpuChart').getContext('2d'), {
        type: chartType,
        data: {
            labels: [],
            datasets: [{
                label: 'CPU Usage %',
                data: [],
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                ...chartConfig[chartType]
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    ...commonOptions.scales.y,
                    max: 100,
                    title: { text: 'Usage %' }
                }
            },
            plugins: {
                title: { display: true, text: 'CPU Usage' }
            }
        }
    });

    // Initialize Memory Chart
    memoryChart = new Chart(document.getElementById('memoryChart').getContext('2d'), {
        type: chartType,
        data: {
            labels: [],
            datasets: [{
                label: 'Memory Usage %',
                data: [],
                borderColor: 'rgb(255, 99, 132)',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                ...chartConfig[chartType]
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    ...commonOptions.scales.y,
                    max: 100,
                    title: { text: 'Usage %' }
                }
            },
            plugins: {
                title: { display: true, text: 'Memory Usage' }
            }
        }
    });

    // Initialize Network Chart
    networkChart = new Chart(document.getElementById('networkChart').getContext('2d'), {
        type: chartType,
        data: {
            labels: [],
            datasets: [{
                label: 'Network In (MB/s)',
                data: [],
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                ...chartConfig[chartType]
            }, {
                label: 'Network Out (MB/s)',
                data: [],
                borderColor: 'rgb(255, 99, 132)',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                ...chartConfig[chartType]
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    title: { text: 'MB/s' }
                }
            },
            plugins: {
                title: { display: true, text: 'Network I/O' }
            }
        }
    });

    // Initialize Disk Chart
    diskChart = new Chart(document.getElementById('diskChart').getContext('2d'), {
        type: chartType,
        data: {
            labels: [],
            datasets: [{
                label: 'Read (MB/s)',
                data: [],
                borderColor: 'rgb(54, 162, 235)',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                ...chartConfig[chartType]
            }, {
                label: 'Write (MB/s)',
                data: [],
                borderColor: 'rgb(255, 206, 86)',
                backgroundColor: 'rgba(255, 206, 86, 0.2)',
                ...chartConfig[chartType]
            }]
        },
        options: {
            ...commonOptions,
            scales: {
                y: {
                    title: { text: 'MB/s' }
                }
            },
            plugins: {
                title: { display: true, text: 'Disk I/O' }
            }
        }
    });
}

function calculateRate(current, last, interval = 5) {
    return ((current - last) / interval).toFixed(2);
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function updateCharts() {
    fetch('/api/metrics')
        .then(response => response.json())
        .then(data => {
            const timestamp = new Date().toLocaleTimeString();

            // Update real-time metrics
            document.getElementById('cpuPercent').textContent = data.cpu_percent.toFixed(1);
            document.getElementById('memoryPercent').textContent = data.memory_percent.toFixed(1);
            document.getElementById('memoryAvailable').textContent = formatBytes(data.memory_available);

            // Calculate network rates
            const networkInRate = calculateRate(data.network.bytes_recv, lastNetworkIn);
            const networkOutRate = calculateRate(data.network.bytes_sent, lastNetworkOut);
            document.getElementById('networkIn').textContent = networkInRate;
            document.getElementById('networkOut').textContent = networkOutRate;

            // Calculate disk rates
            const diskReadRate = calculateRate(data.disk.bytes_read, lastDiskRead);
            const diskWriteRate = calculateRate(data.disk.bytes_written, lastDiskWrite);
            document.getElementById('diskRead').textContent = diskReadRate;
            document.getElementById('diskWrite').textContent = diskWriteRate;

            // Update temperature if available
            if (data.temperature) {
                document.getElementById('cpuTemp').textContent = data.temperature.toFixed(1);
            }

            // Update charts
            updateChart(cpuChart, timestamp, data.cpu_percent);
            updateChart(memoryChart, timestamp, data.memory_percent);
            updateNetworkChart(timestamp, networkInRate, networkOutRate);
            updateDiskChart(timestamp, diskReadRate, diskWriteRate);

            // Update last values
            lastNetworkIn = data.network.bytes_recv;
            lastNetworkOut = data.network.bytes_sent;
            lastDiskRead = data.disk.bytes_read;
            lastDiskWrite = data.disk.bytes_written;

            // Update process table
            updateProcessTable(data.processes);
            window.lastProcessData = data.processes; // Store for later use in search
        })
        .catch(error => console.error('Error fetching metrics:', error));
}

function updateChart(chart, label, value) {
    chart.data.labels.push(label);
    chart.data.datasets[0].data.push(value);

    if (chart.data.labels.length > 10) {
        chart.data.labels.shift();
        chart.data.datasets[0].data.shift();
    }

    chart.update();
}

function updateNetworkChart(label, inRate, outRate) {
    networkChart.data.labels.push(label);
    networkChart.data.datasets[0].data.push(inRate);
    networkChart.data.datasets[1].data.push(outRate);

    if (networkChart.data.labels.length > 10) {
        networkChart.data.labels.shift();
        networkChart.data.datasets.forEach(dataset => dataset.data.shift());
    }

    networkChart.update();
}

function updateDiskChart(label, readRate, writeRate) {
    diskChart.data.labels.push(label);
    diskChart.data.datasets[0].data.push(readRate);
    diskChart.data.datasets[1].data.push(writeRate);

    if (diskChart.data.labels.length > 10) {
        diskChart.data.labels.shift();
        diskChart.data.datasets.forEach(dataset => dataset.data.shift());
    }

    diskChart.update();
}

function updateProcessTable(processes) {
    const tbody = document.querySelector('#processTable tbody');
    const searchTerm = document.getElementById('processSearch').value.toLowerCase();

    tbody.innerHTML = '';
    processes
        .filter(proc => proc.name.toLowerCase().includes(searchTerm))
        .forEach(proc => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${proc.pid}</td>
                <td>${proc.name}</td>
                <td>${proc.cpu_percent.toFixed(1)}%</td>
                <td>${proc.memory_percent.toFixed(1)}%</td>
                <td><span class="badge bg-${proc.status === 'running' ? 'success' : 'warning'}">${proc.status}</span></td>
                <td>${new Date(proc.create_time * 1000).toLocaleString()}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-danger process-action" data-action="terminate" data-pid="${proc.pid}">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
}

// Bulk Actions
function toggleDeviceSelection(deviceId) {
    const checkbox = document.querySelector(`#device-${deviceId}`);
    if (checkbox.checked) {
        selectedDevices.add(deviceId);
    } else {
        selectedDevices.delete(deviceId);
    }
    updateBulkActionButton();
}

function updateBulkActionButton() {
    const bulkActionBtn = document.getElementById('bulkActionBtn');
    if (bulkActionBtn) {
        bulkActionBtn.disabled = selectedDevices.size === 0;
        bulkActionBtn.textContent = `Bulk Actions (${selectedDevices.size})`;
    }
}

async function executeBulkAction() {
    const action = document.getElementById('bulkAction').value;
    if (!action || selectedDevices.size === 0) return;

    try {
        const response = await fetch('/api/devices/bulk', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action,
                devices: Array.from(selectedDevices),
                options: getBulkActionOptions(action)
            })
        });

        if (!response.ok) {
            throw new Error('Failed to execute bulk action');
        }

        // Refresh device list
        location.reload();
    } catch (error) {
        console.error('Error executing bulk action:', error);
        alert('Failed to execute bulk action. Please try again.');
    }
}

function getBulkActionOptions(action) {
    switch (action) {
        case 'move':
            return {
                groupId: document.getElementById('targetGroup').value
            };
        default:
            return {};
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Initialize charts
    initializeCharts();
    updateCharts();
    updateInterval = setInterval(updateCharts, 5000);

    // Enhanced search functionality
    const searchInput = document.querySelector('.search-input');
    let currentGroup = 'All Devices';

    searchInput?.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        filterDevices(searchTerm, currentGroup);
    });

    // Device group filtering
    document.querySelectorAll('.list-group-item-action').forEach(groupLink => {
        groupLink.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.list-group-item-action').forEach(link => {
                link.classList.remove('active');
            });
            groupLink.classList.add('active');

            currentGroup = groupLink.textContent.trim().split('\n')[0];
            const searchTerm = searchInput?.value.toLowerCase() || '';
            filterDevices(searchTerm, currentGroup);
        });
    });

    // Device action buttons
    document.querySelectorAll('.device-row').forEach(deviceRow => {
        const deviceId = deviceRow.dataset.deviceId;

        deviceRow.querySelector('.view-device')?.addEventListener('click', () => {
            window.location.href = `/device/${deviceId}/details`;
        });

        deviceRow.querySelector('.remote-control')?.addEventListener('click', () => {
            window.location.href = `/device/${deviceId}/remote`;
        });

        deviceRow.querySelector('.device-settings')?.addEventListener('click', () => {
            window.location.href = `/device/${deviceId}/settings`;
        });

        deviceRow.querySelector('.delete-device')?.addEventListener('click', async () => {
            if (!confirm('Are you sure you want to remove this device?')) {
                return;
            }

            try {
                const response = await fetch(`/api/devices/${deviceId}`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || 'Failed to delete device');
                }

                deviceRow.remove();

                // Update device counts
                const groupBadges = document.querySelectorAll('.badge');
                groupBadges.forEach(badge => {
                    const count = parseInt(badge.textContent);
                    if (!isNaN(count)) {
                        badge.textContent = count - 1;
                    }
                });

            } catch (error) {
                console.error('Error deleting device:', error);
                alert(error.message || 'Failed to delete device. Please try again.');
            }
        });
         // Add checkbox for bulk selection
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `device-${deviceId}`;
        checkbox.classList.add('form-check-input');
        checkbox.addEventListener('change', () => toggleDeviceSelection(deviceId));
        deviceRow.prepend(checkbox);
    });

    // Add device form handling
    const addDeviceForm = document.getElementById('addDeviceForm');
    addDeviceForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(addDeviceForm);
        const data = Object.fromEntries(formData);

        try {
            const response = await fetch('/api/devices', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to add device');
            }

            // Reset form and close modal
            addDeviceForm.reset();
            const modal = bootstrap.Modal.getInstance(document.getElementById('addDeviceModal'));
            modal.hide();

            // Reload page to show new device
            window.location.reload();

        } catch (error) {
            console.error('Error adding device:', error);
            alert(error.message || 'Failed to add device. Please try again.');
        }
    });


    // Refresh devices
    document.getElementById('refreshDevices')?.addEventListener('click', () => {
        window.location.reload();
    });

    // Live update toggle
    const toggleButton = document.getElementById('toggleLiveUpdate');
    toggleButton?.addEventListener('click', () => {
        const icon = toggleButton.querySelector('i');
        if (updateInterval) {
            clearInterval(updateInterval);
            updateInterval = null;
            icon.setAttribute('data-feather', 'play-circle');
        } else {
            updateInterval = setInterval(updateCharts, 5000);
            icon.setAttribute('data-feather', 'pause-circle');
        }
        feather.replace();
    });

    // Manual refresh
    document.getElementById('refreshMetrics')?.addEventListener('click', updateCharts);

    // Agent Installation Management
    const createInstallCodeForm = document.getElementById('createInstallCodeForm');
    if (createInstallCodeForm) {
        createInstallCodeForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(createInstallCodeForm);
            const data = Object.fromEntries(formData);

            try {
                const response = await fetch('/api/install-codes', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || 'Failed to create installation code');
                }

                const newCode = await response.json();

                // Add new code to the table
                const tbody = document.getElementById('installCodesList');
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>
                        ${newCode.client_name}<br>
                        <small class="text-muted">${data.client_email}</small>
                    </td>
                    <td>
                        <code>${newCode.code}</code>
                        <button class="btn btn-sm btn-outline-secondary copy-code" 
                                data-bs-toggle="tooltip" 
                                title="Copy Code"
                                data-code="${newCode.code}">
                            <i class="fas fa-copy"></i>
                        </button>
                    </td>
                    <td>${data.platform}</td>
                    <td><span class="badge bg-success">Active</span></td>
                    <td>
                        ${new Date(newCode.expires_at).toLocaleString()}<br>
                        <small class="text-muted">Used: 0/${newCode.max_uses}</small>
                    </td>
                    <td>
                        <div class="btn-group">
                            <button class="btn btn-sm btn-outline-primary view-install-link"
                                    data-code="${newCode.code}"
                                    title="View Installation Link">
                                <i class="fas fa-link"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger revoke-code"
                                    data-code="${newCode.code}"
                                    title="Revoke Code">
                                <i class="fas fa-ban"></i>
                            </button>
                        </div>
                    </td>
                `;
                tbody.insertBefore(row, tbody.firstChild);
                createInstallCodeForm.reset();

                // Initialize tooltips for new elements
                const tooltips = row.querySelectorAll('[data-bs-toggle="tooltip"]');
                tooltips.forEach(el => new bootstrap.Tooltip(el));

            } catch (error) {
                console.error('Error creating installation code:', error);
                alert(error.message || 'Failed to create installation code');
            }
        });
    }

    // Copy installation code
    document.addEventListener('click', async (e) => {
        if (e.target.closest('.copy-code')) {
            const button = e.target.closest('.copy-code');
            const code = button.dataset.code;
            try {
                await navigator.clipboard.writeText(code);
                const tooltip = bootstrap.Tooltip.getInstance(button);
                const originalTitle = button.getAttribute('title');
                button.setAttribute('title', 'Copied!');
                tooltip.dispose();
                new bootstrap.Tooltip(button).show();
                setTimeout(() => {
                    button.setAttribute('title', originalTitle);
                    tooltip.dispose();
                    new bootstrap.Tooltip(button);
                }, 1500);
            } catch (err) {
                console.error('Failed to copy code:', err);
            }
        }
    });

    // View installation link
    document.addEventListener('click', async (e) => {
        if (e.target.closest('.view-install-link')) {
            const button = e.target.closest('.view-install-link');
            const code = button.dataset.code;
            const modal = new bootstrap.Modal(document.getElementById('installLinkModal'));
            const urlInput = document.getElementById('installUrl');
            const installUrl = `${window.location.origin}/install/${code}`;
            urlInput.value = installUrl;
            modal.show();
        }
    });

    // Copy installation URL
    document.querySelector('.copy-url')?.addEventListener('click', async () => {
        const urlInput = document.getElementById('installUrl');
        try {
            await navigator.clipboard.writeText(urlInput.value);
            const button = document.querySelector('.copy-url');
            const icon = button.querySelector('i');
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check"></i> Copied!';
            setTimeout(() => {
                button.innerHTML = originalText;
            }, 1500);
        } catch (err) {
            console.error('Failed to copy URL:', err);
        }
    });

    // Revoke installation code
    document.addEventListener('click', async (e) => {
        if (e.target.closest('.revoke-code')) {
            const button = e.target.closest('.revoke-code');
            const code = button.dataset.code;
            if (!confirm('Are you sure you want to revoke this installation code?')) {
                return;
            }

            try {
                const response = await fetch(`/api/install-codes/${code}/revoke`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        reason: 'Manually revoked by administrator'
                    })
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error || 'Failed to revoke code');
                }

                // Update UI
                const row = button.closest('tr');
                const statusCell = row.querySelector('td:nth-child(4)');
                statusCell.innerHTML = '<span class="badge bg-danger">Revoked</span>';
                row.classList.add('text-muted');
                button.disabled = true;

            } catch (error) {
                console.error('Error revoking code:', error);
                alert(error.message || 'Failed to revoke code');
            }
        }
    });

    // Initialize tooltips
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
        new bootstrap.Tooltip(el);
    });

    // Chart type selection
    document.querySelectorAll('[data-chart-type]').forEach(button => {
        button.addEventListener('click', (e) => {
            chartType = e.target.dataset.chartType;
            // Reinitialize charts with new type
            initializeCharts();
            updateCharts(); // Update charts after changing type
        });
    });

    // Process search
    document.getElementById('processSearch')?.addEventListener('input', (e) => {
        updateProcessTable(window.lastProcessData || []);
    });

    // Process actions
    document.addEventListener('click', async (e) => {
        if (e.target.closest('.process-action')) {
            const button = e.target.closest('.process-action');
            const { action, pid } = button.dataset;

            if (confirm(`Are you sure you want to ${action} process ${pid}?`)) {
                try {
                    const response = await fetch(`/api/processes/${pid}/${action}`, {
                        method: 'POST'
                    });

                    if (!response.ok) {
                        throw new Error(`Failed to ${action} process`);
                    }

                    // Refresh process table
                    updateCharts();
                } catch (error) {
                    console.error(`Error ${action}ing process:`, error);
                    alert(`Failed to ${action} process. Please try again.`);
                }
            }
        }
    });

    // Bulk actions
    document.getElementById('executeBulkAction')?.addEventListener('click', executeBulkAction);

    document.getElementById('bulkAction')?.addEventListener('change', (e) => {
        const actionSpecificOptions = document.getElementById('actionSpecificOptions');
        const action = e.target.value;

        switch (action) {
            case 'move':
                actionSpecificOptions.innerHTML = `
                    <div class="mb-3">
                        <label class="form-label">Target Group</label>
                        <select class="form-select" id="targetGroup">
                            <option value="">Select Group...</option>
                            ${Array.from(document.querySelectorAll('#groupsList .group-item'))
                                .map(group => `<option value="${group.dataset.groupId}">${group.textContent}</option>`)
                                .join('')}
                        </select>
                    </div>
                `;
                break;
            default:
                actionSpecificOptions.innerHTML = '';
        }
    });
    //Search and filter functionality
    function filterDevices(searchTerm, groupName) {
        const deviceRows = document.querySelectorAll('.device-row');
        deviceRows.forEach(row => {
            const deviceName = row.querySelector('.device-name').textContent.toLowerCase();
            const deviceDetails = row.querySelector('.device-details').textContent.toLowerCase();
            const deviceGroup = row.getAttribute('data-group') || '';
            const matchesSearch = searchTerm === '' ||
                                  deviceName.includes(searchTerm) ||
                                  deviceDetails.includes(searchTerm);
            const matchesGroup = groupName === 'All Devices' || deviceGroup === groupName;

            row.style.display = matchesSearch && matchesGroup ? '' : 'none';
        });
    }
});