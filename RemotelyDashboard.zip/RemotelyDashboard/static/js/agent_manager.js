document.addEventListener('DOMContentLoaded', () => {
    const createAgentForm = document.getElementById('createAgentForm');
    
    createAgentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = {
            name: document.getElementById('agentName').value,
            group_id: document.getElementById('agentGroup').value,
            template: document.getElementById('agentTemplate').value,
            platform: document.getElementById('agentPlatform').value
        };

        try {
            const response = await fetch('/api/devices/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();
            
            if (response.ok) {
                // Download the agent package
                window.location.href = `/download-agent/${formData.platform}?device_id=${data.device_id}`;
            } else {
                alert(data.error || 'Failed to create agent');
            }
        } catch (error) {
            console.error('Error creating agent:', error);
            alert('Failed to create agent. Please try again.');
        }
    });
});
