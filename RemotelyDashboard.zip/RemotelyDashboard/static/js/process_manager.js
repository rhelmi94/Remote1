class ProcessManager {
    constructor() {
        this.initializeCharts();
        this.initializeWebSocket();
        this.initializeEventListeners();
        this.selectedProcesses = new Set();
        this.updateInterval = setInterval(() => this.updateMetrics(), 5000);
        this.alertThresholds = {
            cpu: 80,
            memory: 90,
            disk: 85
        };
        this.updateMetrics();
    }

    initializeWebSocket() {
        this.socket = io('/process_monitor');

        this.socket.on('connect', () => {
            console.log('Process monitor connected');
        });

        this.socket.on('metrics_update', (data) => {
            this.updateMetrics(data);
        });

        this.socket.on('process_alert', (data) => {
            this.handleProcessAlert(data);
        });

        this.socket.on('error', (error) => {
            console.error('WebSocket error:', error);
            this.showAlert('error', 'Lost connection to process monitor');
        });
    }

    initializeCharts() {
        const commonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 750 },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255,255,255,0.1)' }
                },
                x: {
                    grid: { color: 'rgba(255,255,255,0.1)' }
                }
            },
            plugins: {
                legend: { position: 'top' }
            }
        };

        // CPU Usage Chart
        this.cpuChart = new Chart(document.getElementById('cpuChart').getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'CPU Usage %',
                    data: [],
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    fill: true
                }]
            },
            options: {
                ...commonOptions,
                scales: {
                    y: {
                        ...commonOptions.scales.y,
                        max: 100
                    }
                }
            }
        });

        // Memory Usage Chart
        this.memoryChart = new Chart(document.getElementById('memoryChart').getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Memory Usage %',
                    data: [],
                    borderColor: 'rgb(255, 99, 132)',
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    fill: true
                }]
            },
            options: {
                ...commonOptions,
                scales: {
                    y: {
                        ...commonOptions.scales.y,
                        max: 100
                    }
                }
            }
        });

        // I/O Activity Chart
        this.ioChart = new Chart(document.getElementById('ioChart').getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Read MB/s',
                    data: [],
                    borderColor: 'rgb(54, 162, 235)',
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    fill: true
                }, {
                    label: 'Write MB/s',
                    data: [],
                    borderColor: 'rgb(255, 206, 86)',
                    backgroundColor: 'rgba(255, 206, 86, 0.2)',
                    fill: true
                }]
            },
            options: commonOptions
        });

        // Network Activity Chart
        this.networkChart = new Chart(document.getElementById('networkChart').getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Incoming MB/s',
                    data: [],
                    borderColor: 'rgb(153, 102, 255)',
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    fill: true
                }, {
                    label: 'Outgoing MB/s',
                    data: [],
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    fill: true
                }]
            },
            options: commonOptions
        });
    }

    initializeEventListeners() {
        // Process selection
        document.getElementById('selectAllProcesses')?.addEventListener('change', (e) => {
            document.querySelectorAll('.process-checkbox').forEach(checkbox => {
                checkbox.checked = e.target.checked;
                this.toggleProcessSelection(checkbox.value, e.target.checked);
            });
        });

        // Process search
        document.getElementById('processSearch')?.addEventListener('input', (e) => {
            this.filterProcesses(e.target.value);
        });

        // Filter dropdown
        document.querySelectorAll('[data-filter]').forEach(filter => {
            filter.addEventListener('click', (e) => {
                e.preventDefault();
                this.applyFilter(e.target.dataset.filter);
            });
        });

        // Process actions
        document.addEventListener('click', (e) => {
            const actionButton = e.target.closest('[data-action]');
            if (actionButton) {
                const action = actionButton.dataset.action;
                const pid = actionButton.dataset.pid;
                this.handleProcessAction(action, pid);
            }
        });

        // Alert settings
        document.getElementById('saveAlertSettings')?.addEventListener('click', () => {
            this.saveAlertSettings();
        });

        // Priority change
        document.getElementById('changePriority')?.addEventListener('click', () => {
            this.changePriority();
        });
    }

    async updateMetrics(data) {
        if (!data) {
            try {
                const response = await fetch('/api/processes/metrics');
                data = await response.json();
            } catch (error) {
                console.error('Error fetching metrics:', error);
                return;
            }
        }

        this.updateSystemStats(data.system);
        this.updateCharts(data.history);
        this.updateProcessList(data.processes);
        this.checkAlertThresholds(data.system);
    }

    updateSystemStats(stats) {
        // Update CPU stats
        document.getElementById('cpuUsage').textContent = `${stats.cpu.usage.toFixed(1)}%`;
        document.getElementById('cpuCores').textContent = stats.cpu.cores;

        // Update Memory stats
        document.getElementById('memoryUsage').textContent = `${stats.memory.usage.toFixed(1)}%`;
        document.getElementById('memoryAvailable').textContent = this.formatBytes(stats.memory.available);

        // Update Disk I/O stats
        document.getElementById('diskIO').textContent = `${this.calculateIORate(stats.disk_io.total)}`;
        document.getElementById('diskActive').textContent = stats.disk_io.active_ops;

        // Update Network stats
        document.getElementById('networkUsage').textContent =
            `${this.formatBytes(stats.network.bytes_sent + stats.network.bytes_recv)}/s`;
        document.getElementById('networkConnections').textContent = stats.network.connections;
    }

    updateCharts(history) {
        const timestamp = new Date().toLocaleTimeString();

        // Update CPU Chart
        this.updateChart(this.cpuChart, timestamp, history.cpu);

        // Update Memory Chart
        this.updateChart(this.memoryChart, timestamp, history.memory);

        // Update I/O Chart
        this.updateIOChart(timestamp, history.disk_read, history.disk_write);

        // Update Network Chart
        this.updateNetworkChart(timestamp, history.network_in, history.network_out);
    }

    checkAlertThresholds(stats) {
        if (stats.cpu.usage > this.alertThresholds.cpu) {
            this.showAlert('warning', `High CPU usage: ${stats.cpu.usage.toFixed(1)}%`);
        }
        if (stats.memory.usage > this.alertThresholds.memory) {
            this.showAlert('warning', `High memory usage: ${stats.memory.usage.toFixed(1)}%`);
        }
        if (stats.disk.usage > this.alertThresholds.disk) {
            this.showAlert('warning', `High disk usage: ${stats.disk.usage.toFixed(1)}%`);
        }
    }

    async handleProcessAction(action, pid) {
        if (!confirm(`Are you sure you want to ${action} process ${pid}?`)) {
            return;
        }

        try {
            const response = await fetch(`/api/processes/${pid}/${action}`, {
                method: 'POST'
            });

            if (!response.ok) {
                throw new Error(`Failed to ${action} process`);
            }

            this.showAlert('success', `Successfully ${action}ed process ${pid}`);
            this.updateMetrics();

        } catch (error) {
            console.error(`Error ${action}ing process:`, error);
            this.showAlert('error', `Failed to ${action} process. Please try again.`);
        }
    }

    saveAlertSettings() {
        const form = document.getElementById('alertSettingsForm');
        const formData = new FormData(form);

        this.alertThresholds = {
            cpu: parseInt(formData.get('cpu_threshold')),
            memory: parseInt(formData.get('memory_threshold')),
            disk: parseInt(formData.get('disk_threshold'))
        };

        // Save settings to localStorage
        localStorage.setItem('alertThresholds', JSON.stringify(this.alertThresholds));
        this.showAlert('success', 'Alert settings saved successfully');
    }

    async changePriority() {
        const pid = this.selectedProcess;
        const priority = document.querySelector('#priorityForm select').value;

        try {
            const response = await fetch(`/api/processes/${pid}/priority`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ priority })
            });

            if (!response.ok) {
                throw new Error('Failed to change process priority');
            }

            this.showAlert('success', 'Process priority updated successfully');
            this.updateMetrics();
            bootstrap.Modal.getInstance(document.getElementById('priorityModal')).hide();

        } catch (error) {
            console.error('Error changing process priority:', error);
            this.showAlert('error', 'Failed to change process priority');
        }
    }

    formatBytes(bytes) {
        const sizes = ['B', 'KB', 'MB', 'GB'];
        if (bytes === 0) return '0 B';
        const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

    calculateIORate(bytes) {
        return (bytes / (1024 * 1024)).toFixed(2); // Convert to MB/s
    }

    showAlert(type, message) {
        const toast = new bootstrap.Toast(document.getElementById('alertToast'));
        const toastBody = document.querySelector('#alertToast .toast-body');
        if (toastBody) {
            toastBody.textContent = message;
            toastBody.className = `toast-body text-${type}`;
            toast.show();
        }
    }

    cleanup() {
        this.socket?.disconnect();
        clearInterval(this.updateInterval);
    }


    updateChart(chart, label, value) {
        chart.data.labels.push(label);
        chart.data.datasets[0].data.push(value);

        if (chart.data.labels.length > 10) {
            chart.data.labels.shift();
            chart.data.datasets[0].data.shift();
        }

        chart.update();
    }

    updateIOChart(label, readRate, writeRate) {
        this.ioChart.data.labels.push(label);
        this.ioChart.data.datasets[0].data.push(readRate);
        this.ioChart.data.datasets[1].data.push(writeRate);

        if (this.ioChart.data.labels.length > 10) {
            this.ioChart.data.labels.shift();
            this.ioChart.data.datasets.forEach(dataset => dataset.data.shift());
        }

        this.ioChart.update();
    }

    updateNetworkChart(label, incoming, outgoing) {
        this.networkChart.data.labels.push(label);
        this.networkChart.data.datasets[0].data.push(incoming);
        this.networkChart.data.datasets[1].data.push(outgoing);

        if (this.networkChart.data.labels.length > 10) {
            this.networkChart.data.labels.shift();
            this.networkChart.data.datasets.forEach(dataset => dataset.data.shift());
        }

        this.networkChart.update();
    }

    async updateProcessList(processes) {
        const tbody = document.querySelector('#processList');
        if (!tbody) return;

        const searchTerm = document.getElementById('processSearch')?.value.toLowerCase() || '';

        tbody.innerHTML = processes
            .filter(proc =>
                proc.name.toLowerCase().includes(searchTerm) ||
                proc.pid.toString().includes(searchTerm)
            )
            .map(proc => `
                <tr>
                    <td>
                        <div class="form-check">
                            <input class="form-check-input process-checkbox" type="checkbox" name="process" value="${proc.pid}">
                        </div>
                    </td>
                    <td>${proc.name}</td>
                    <td>${proc.pid}</td>
                    <td>${proc.cpu_percent.toFixed(1)}%</td>
                    <td>${proc.memory_percent.toFixed(1)}%</td>
                    <td>
                        <span class="badge bg-${proc.status === 'running' ? 'success' : 'warning'}">
                            ${proc.status}
                        </span>
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary" data-action="view" data-pid="${proc.pid}"
                                    title="View Details">
                                <i class="fas fa-info-circle"></i>
                            </button>
                            <button class="btn btn-outline-warning" data-action="suspend" data-pid="${proc.pid}"
                                    title="Suspend Process">
                                <i class="fas fa-pause"></i>
                            </button>
                            <button class="btn btn-outline-danger" data-action="terminate" data-pid="${proc.pid}"
                                    title="Terminate Process">
                                <i class="fas fa-stop"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `).join('');
    }

    toggleProcessSelection(pid, selected) {
        if (selected) {
            this.selectedProcesses.add(pid);
        } else {
            this.selectedProcesses.delete(pid);
        }
        this.updateBulkActionButtons();
    }

    updateBulkActionButtons() {
        const buttons = document.querySelectorAll('.bulk-action');
        const hasSelection = this.selectedProcesses.size > 0;
        buttons.forEach(button => button.disabled = !hasSelection);
    }

    filterProcesses(searchTerm) {
        const rows = document.querySelectorAll('#processList tr');
        searchTerm = searchTerm.toLowerCase();

        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    }
    applyFilter(filterType) {
        //Implementation for filterType
    }
}

// Initialize process manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.processManager = new ProcessManager();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    window.processManager?.cleanup();
});

function formatBytes(bytes) {
    const sizes = ['B', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 B';
    const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
}