class NetworkMap {
    constructor(selector) {
        this.svg = d3.select(selector);
        this.width = this.svg.node().getBoundingClientRect().width;
        this.height = 600; // Increased height for better visualization
        this.simulation = null;
        this.nodes = [];
        this.links = [];
        this.zoomLevel = 1;
        this.currentLayout = 0; // Initialize layout index

        // Enhanced tooltip with more device info
        this.tooltip = d3.select("body").append("div")
            .attr("class", "network-tooltip")
            .style("opacity", 0);

        // Initialize visualization
        this.init();
        this.initializeControls();
    }

    init() {
        // Enhanced arrow marker for links
        this.svg.append("defs").selectAll("marker")
            .data(["standard", "active", "warning", "error"])
            .enter().append("marker")
            .attr("id", d => `arrowhead-${d}`)
            .attr("viewBox", "-0 -5 10 10")
            .attr("refX", 20)
            .attr("refY", 0)
            .attr("orient", "auto")
            .attr("markerWidth", 6)
            .attr("markerHeight", 6)
            .append("path")
            .attr("d", "M0,-5L10,0L0,5")
            .attr("fill", d => this.getMarkerColor(d));

        // Initialize force simulation with improved forces
        this.simulation = d3.forceSimulation()
            .force("link", d3.forceLink().id(d => d.id).distance(100))
            .force("charge", d3.forceManyBody().strength(-300))
            .force("center", d3.forceCenter(this.width / 2, this.height / 2))
            .force("collision", d3.forceCollide().radius(30))
            .force("x", d3.forceX(this.width / 2).strength(0.05))
            .force("y", d3.forceY(this.height / 2).strength(0.05));

        // Add zoom behavior
        const zoom = d3.zoom()
            .scaleExtent([0.1, 4])
            .on("zoom", (event) => {
                this.zoomLevel = event.transform.k;
                this.svg.selectAll("g").attr("transform", event.transform);
            });

        this.svg.call(zoom);
    }

    initializeControls() {
        // Add event listeners for control buttons
        d3.select("#zoomIn").on("click", () => this.zoom(1.2));
        d3.select("#zoomOut").on("click", () => this.zoom(0.8));
        d3.select("#zoomReset").on("click", () => this.resetZoom());

        // Add layout toggle functionality
        d3.select("#toggleLayout").on("click", () => this.toggleLayout());
    }

    getMarkerColor(type) {
        switch(type) {
            case "active": return "#28a745";
            case "warning": return "#ffc107";
            case "error": return "#dc3545";
            default: return "#6c757d";
        }
    }

    getHealthColor(status, latency) {
        if (status === 'error' || latency > 1000) return '#dc3545';
        if (status === 'warning' || latency > 500) return '#ffc107';
        if (status === 'healthy') return '#28a745';
        return '#6c757d';
    }

    showTooltip(event, d) {
        let content = `
            <div class="device-tooltip">
                <h6>${d.name || d.ip}</h6>
                <div class="tooltip-details">
                    <p><strong>Status:</strong> ${d.status}</p>
                    <p><strong>Latency:</strong> ${d.latency}ms</p>
                    ${d.cpu_usage ? `<p><strong>CPU:</strong> ${d.cpu_usage}%</p>` : ''}
                    ${d.memory_usage ? `<p><strong>Memory:</strong> ${d.memory_usage}%</p>` : ''}
                    ${d.group_name ? `<p><strong>Group:</strong> ${d.group_name}</p>` : ''}
                </div>
            </div>
        `;

        this.tooltip.html(content)
            .style("left", (event.pageX + 10) + "px")
            .style("top", (event.pageY - 28) + "px")
            .transition()
            .duration(200)
            .style("opacity", .9);
    }

    hideTooltip() {
        this.tooltip.transition()
            .duration(500)
            .style("opacity", 0);
    }

    update(data) {
        // Process data into nodes and links
        const nodes = [{ id: "localhost", type: "host", name: "Local System" }];
        const links = [];
        const groups = new Map();

        // Process devices and their connections
        data.devices.forEach(device => {
            const nodeId = `${device.ip}:${device.port}`;
            nodes.push({
                id: nodeId,
                ...device,
                type: "device"
            });

            if (device.group_id) {
                if (!groups.has(device.group_id)) {
                    groups.set(device.group_id, []);
                }
                groups.get(device.group_id).push(nodeId);
            }

            links.push({
                source: "localhost",
                target: nodeId,
                status: device.status,
                latency: device.latency
            });
        });

        // Update visualization
        this.updateLinks(links);
        this.updateNodes(nodes);
        this.updateGroups(groups);

        // Update simulation
        this.simulation
            .nodes(nodes)
            .on("tick", () => this.tick());

        this.simulation.force("link")
            .links(links);

        // Reheat simulation
        this.simulation.alpha(1).restart();
    }

    updateLinks(links) {
        const link = this.svg.selectAll(".link")
            .data(links, d => `${d.source.id || d.source}:${d.target.id || d.target}`);

        // Remove old links
        link.exit().remove();

        // Add new links
        const linkEnter = link.enter().append("line")
            .attr("class", "link")
            .attr("stroke-width", d => this.getLinkWidth(d.status))
            .attr("stroke", d => this.getHealthColor(d.status, d.latency))
            .attr("marker-end", d => `url(#arrowhead-${this.getLinkStatus(d.status)})`);

        // Update existing links
        link.merge(linkEnter)
            .attr("stroke-width", d => this.getLinkWidth(d.status))
            .attr("stroke", d => this.getHealthColor(d.status, d.latency))
            .attr("marker-end", d => `url(#arrowhead-${this.getLinkStatus(d.status)})`);
    }

    updateNodes(nodes) {
        const node = this.svg.selectAll(".node")
            .data(nodes, d => d.id);

        // Remove old nodes
        node.exit().remove();

        // Add new nodes
        const nodeEnter = node.enter().append("g")
            .attr("class", "node")
            .call(d3.drag()
                .on("start", (event, d) => this.dragstarted(event, d))
                .on("drag", (event, d) => this.dragged(event, d))
                .on("end", (event, d) => this.dragended(event, d)));

        // Add node circles
        nodeEnter.append("circle")
            .attr("r", d => d.type === "host" ? 15 : 8)
            .attr("fill", d => this.getNodeFill(d))
            .attr("stroke", d => this.getHealthColor(d.status, d.latency))
            .attr("stroke-width", 2);

        // Add node labels
        nodeEnter.append("text")
            .attr("dy", ".35em")
            .attr("x", 12)
            .text(d => this.getNodeLabel(d));

        // Add hover events
        nodeEnter
            .on("mouseover", (event, d) => this.showTooltip(event, d))
            .on("mouseout", () => this.hideTooltip())
            .on("click", (event, d) => this.handleNodeClick(d));

        // Update existing nodes
        const nodeUpdate = node.merge(nodeEnter);
        nodeUpdate.select("circle")
            .attr("fill", d => this.getNodeFill(d))
            .attr("stroke", d => this.getHealthColor(d.status, d.latency));
    }

    updateGroups(groups) {
        // Create convex hulls around device groups
        const hulls = this.svg.selectAll(".hull")
            .data(Array.from(groups.entries()));

        hulls.exit().remove();

        const hullEnter = hulls.enter()
            .append("path")
            .attr("class", "hull")
            .attr("fill", ([groupId]) => this.getGroupColor(groupId))
            .attr("fill-opacity", 0.1)
            .attr("stroke", ([groupId]) => this.getGroupColor(groupId))
            .attr("stroke-opacity", 0.3);

        hulls.merge(hullEnter)
            .attr("d", ([_, groupNodes]) => {
                const points = groupNodes
                    .map(nodeId => {
                        const node = this.simulation.nodes().find(n => n.id === nodeId);
                        return node ? [node.x, node.y] : null;
                    })
                    .filter(p => p !== null);

                return points.length < 3 ? null : `M${d3.polygonHull(points).join("L")}Z`;
            });
    }

    tick() {
        // Update link positions
        this.svg.selectAll(".link")
            .attr("x1", d => d.source.x)
            .attr("y1", d => d.source.y)
            .attr("x2", d => d.target.x)
            .attr("y2", d => d.target.y);

        // Update node positions
        this.svg.selectAll(".node")
            .attr("transform", d => `translate(${d.x},${d.y})`);

        // Update hull positions
        this.updateGroups(this.getGroupsFromNodes());
    }

    getGroupsFromNodes() {
        const groups = new Map();
        this.simulation.nodes().forEach(node => {
            if (node.group_id) {
                if (!groups.has(node.group_id)) {
                    groups.set(node.group_id, []);
                }
                groups.get(node.group_id).push(node.id);
            }
        });
        return groups;
    }

    zoom(factor) {
        const zoom = d3.zoom().scaleExtent([0.1, 4]);
        this.svg.transition()
            .duration(750)
            .call(zoom.transform, d3.zoomIdentity.scale(this.zoomLevel * factor));
    }

    resetZoom() {
        const zoom = d3.zoom().scaleExtent([0.1, 4]);
        this.svg.transition()
            .duration(750)
            .call(zoom.transform, d3.zoomIdentity);
    }

    toggleLayout() {
        // Toggle between different layout algorithms
        const layouts = {
            radial: d3.forceRadial(100, this.width / 2, this.height / 2),
            grid: this.createGridForce(),
            standard: null
        };

        // Cycle through layouts
        this.currentLayout = (this.currentLayout + 1) % Object.keys(layouts).length;
        const layout = layouts[Object.keys(layouts)[this.currentLayout]];

        this.simulation
            .force("radial", layout)
            .alpha(1)
            .restart();
    }

    createGridForce() {
        const gridSize = Math.ceil(Math.sqrt(this.simulation.nodes().length));
        const cellSize = Math.min(this.width, this.height) / gridSize;

        return (alpha) => {
            this.simulation.nodes().forEach((d, i) => {
                const col = i % gridSize;
                const row = Math.floor(i / gridSize);
                d.x += (this.width/2 + (col - gridSize/2) * cellSize - d.x) * alpha;
                d.y += (this.height/2 + (row - gridSize/2) * cellSize - d.y) * alpha;
            });
        };
    }

    // Drag handlers
    dragstarted(event, d) {
        if (!event.active) this.simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
    }

    dragged(event, d) {
        d.fx = event.x;
        d.fy = event.y;
    }

    dragended(event, d) {
        if (!event.active) this.simulation.alphaTarget(0);
        d.fx = null;
        d.fy = null;
    }

    // Helper methods
    getLinkWidth(status) {
        switch(status) {
            case 'healthy': return 3;
            case 'warning': return 2;
            default: return 1;
        }
    }

    getLinkStatus(status) {
        switch(status) {
            case 'healthy': return 'active';
            case 'warning': return 'warning';
            case 'error': return 'error';
            default: return 'standard';
        }
    }

    getNodeFill(node) {
        if (node.type === "host") return "#ff7f0e";
        return this.getGroupColor(node.group_id) || "#95a5a6";
    }

    getNodeLabel(node) {
        if (node.type === "host") return "Local";
        return node.name || node.ip;
    }

    getGroupColor(groupId) {
        const colors = [
            '#3498db', '#e74c3c', '#2ecc71', '#f1c40f',
            '#9b59b6', '#1abc9c', '#e67e22', '#34495e'
        ];
        return groupId ? colors[groupId % colors.length] : '#95a5a6';
    }

    handleNodeClick(node) {
        // Placeholder for future node click handling
        console.log("Node clicked:", node);
    }

    updateNodeStatus(data) {
        const node = this.svg.selectAll(".node").filter(n => n.id === data.id);
        if (node.empty()) {
            console.warn(`Node with id ${data.id} not found`);
            return;
        }

        node.select("circle").attr("stroke", this.getHealthColor(data.status, data.latency));
        node.select("text").text(this.getNodeLabel(data));
    }
}

// Add custom styles for the network map
const style = document.createElement('style');
style.textContent = `
    .network-map {
        background: var(--bs-body-bg);
        border-radius: 4px;
        overflow: hidden;
        position: relative;
    }
    .network-map svg {
        display: block;
    }
    .network-map .link {
        stroke-width: 2px;
    }
    .network-map .node text {
        fill: var(--bs-body-color);
        font-family: var(--bs-font-sans-serif);
    }
    .network-tooltip {
        position: absolute;
        padding: 10px;
        background: var(--bs-dark);
        color: var(--bs-light);
        border-radius: 4px;
        pointer-events: none;
        opacity: 0;
        max-width: 300px;
    }
    .device-tooltip h6 {
        margin: 0 0 8px 0;
        color: var(--bs-primary);
    }
    .tooltip-details p {
        margin: 4px 0;
        font-size: 12px;
    }
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.6; }
        100% { opacity: 1; }
    }
`;
document.head.appendChild(style);

// Initialize network map and update periodically
document.addEventListener('DOMContentLoaded', () => {
    const networkMap = new NetworkMap('#networkMap');

    function updateNetworkMap() {
        fetch('/api/network/topology')
            .then(response => response.json())
            .then(data => networkMap.update(data))
            .catch(error => console.error('Error updating network map:', error));
    }

    // Initial update
    updateNetworkMap();

    // Set up WebSocket connection for real-time updates
    const socket = io('/network');
    socket.on('topology_update', data => networkMap.update(data));
    socket.on('device_status_change', data => {
        // Update specific node without full refresh
        networkMap.updateNodeStatus(data);
    });

    // Fallback to polling for updates every 30 seconds
    setInterval(updateNetworkMap, 30000);
});