class MonitoringDashboard {
    constructor() {
        this.charts = {};
        this.settings = {
            updateInterval: 5,
            chartType: 'line',
            thresholds: {
                cpu: { warning: 70, critical: 90 },
                memory: { warning: 80, critical: 95 },
                disk: { warning: 85, critical: 95 }
            }
        };
        this.initializeCharts();
        this.initializeWebSocket();
        this.initializeEventListeners();
        this.startMonitoring();
    }

    initializeWebSocket() {
        this.socket = io('/monitoring');

        this.socket.on('connect', () => {
            console.log('Monitoring dashboard connected');
        });

        this.socket.on('metrics_update', (data) => {
            this.updateMetrics(data);
        });

        this.socket.on('device_alert', (data) => {
            this.handleDeviceAlert(data);
        });

        this.socket.on('error', (error) => {
            console.error('WebSocket error:', error);
            this.showAlert('error', 'Lost connection to monitoring system');
        });
    }

    initializeCharts() {
        const commonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 750 },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255,255,255,0.1)' }
                },
                x: {
                    grid: { color: 'rgba(255,255,255,0.1)' }
                }
            },
            plugins: {
                legend: { display: true }
            }
        };

        // CPU Chart
        this.charts.cpu = new Chart(document.getElementById('cpuChart').getContext('2d'), {
            type: this.settings.chartType,
            data: {
                labels: [],
                datasets: [{
                    label: 'Usage %',
                    data: [],
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    fill: true
                }]
            },
            options: {
                ...commonOptions,
                scales: {
                    y: {
                        ...commonOptions.scales.y,
                        max: 100
                    }
                }
            }
        });

        // Memory Chart
        this.charts.memory = new Chart(document.getElementById('memoryChart').getContext('2d'), {
            type: this.settings.chartType,
            data: {
                labels: [],
                datasets: [{
                    label: 'Usage %',
                    data: [],
                    borderColor: 'rgb(255, 99, 132)',
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    fill: true
                }]
            },
            options: {
                ...commonOptions,
                scales: {
                    y: {
                        ...commonOptions.scales.y,
                        max: 100
                    }
                }
            }
        });

        // Disk Chart
        this.charts.disk = new Chart(document.getElementById('diskChart').getContext('2d'), {
            type: this.settings.chartType,
            data: {
                labels: [],
                datasets: [{
                    label: 'Read MB/s',
                    data: [],
                    borderColor: 'rgb(54, 162, 235)',
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    fill: true
                }, {
                    label: 'Write MB/s',
                    data: [],
                    borderColor: 'rgb(255, 206, 86)',
                    backgroundColor: 'rgba(255, 206, 86, 0.2)',
                    fill: true
                }]
            },
            options: commonOptions
        });

        // Network Chart
        this.charts.network = new Chart(document.getElementById('networkChart').getContext('2d'), {
            type: this.settings.chartType,
            data: {
                labels: [],
                datasets: [{
                    label: 'In MB/s',
                    data: [],
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    fill: true
                }, {
                    label: 'Out MB/s',
                    data: [],
                    borderColor: 'rgb(255, 99, 132)',
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    fill: true
                }]
            },
            options: commonOptions
        });
    }

    initializeEventListeners() {
        // Refresh button
        document.getElementById('refreshDashboard')?.addEventListener('click', () => {
            this.updateMetrics();
        });

        // Filter and search
        document.getElementById('deviceSearch')?.addEventListener('input', (e) => {
            this.filterDevices(e.target.value);
        });

        document.getElementById('groupFilter')?.addEventListener('change', (e) => {
            this.filterByGroup(e.target.value);
        });

        document.getElementById('statusFilter')?.addEventListener('change', (e) => {
            this.filterByStatus(e.target.value);
        });

        document.getElementById('sortBy')?.addEventListener('change', (e) => {
            this.sortDevices(e.target.value);
        });

        // Alert settings
        document.getElementById('saveAlertConfig')?.addEventListener('click', () => {
            this.saveAlertSettings();
        });

        // Alert acknowledgment
        document.addEventListener('click', (e) => {
            if (e.target.closest('.acknowledge-alert')) {
                const alertId = e.target.closest('.acknowledge-alert').dataset.alertId;
                this.acknowledgeAlert(alertId);
            }
        });
    }

    async updateMetrics(data) {
        if (!data) {
            try {
                const response = await fetch('/api/monitoring/metrics');
                data = await response.json();
            } catch (error) {
                console.error('Error fetching metrics:', error);
                return;
            }
        }

        this.updateSystemStats(data.system);
        this.updateCharts(data.history);
        this.updateDeviceList(data.devices);
        this.checkThresholds(data.system);
        this.updateAlerts(data.alerts);
        this.updateDeviceStatus(data.device_status);
    }

    updateSystemStats(stats) {
        // Update overall health score
        document.getElementById('healthScore').textContent = `${stats.health_score}%`;
        document.getElementById('overallHealth').className =
            `health-indicator health-${this.getHealthClass(stats.health_score)}`;

        // Update device counts
        document.getElementById('activeDevices').textContent = stats.active_devices;
        document.getElementById('totalDevices').textContent = stats.total_devices;

        // Update alert count
        document.getElementById('activeAlerts').textContent = stats.active_alerts;

        // Update uptime
        document.getElementById('systemUptime').textContent = this.formatUptime(stats.uptime);
    }

    updateCharts(history) {
        const timestamp = new Date().toLocaleTimeString();

        this.updateChart(this.charts.cpu, timestamp, history.cpu);
        this.updateChart(this.charts.memory, timestamp, history.memory);
        this.updateMultiChart(this.charts.disk, timestamp, [
            history.disk.read_rate,
            history.disk.write_rate
        ]);
        this.updateMultiChart(this.charts.network, timestamp, [
            history.network.in_rate,
            history.network.out_rate
        ]);
    }

    updateChart(chart, label, value) {
        chart.data.labels.push(label);
        chart.data.datasets[0].data.push(value);

        if (chart.data.labels.length > 20) {
            chart.data.labels.shift();
            chart.data.datasets[0].data.shift();
        }

        chart.update();
    }

    updateMultiChart(chart, label, values) {
        chart.data.labels.push(label);
        values.forEach((value, index) => {
            chart.data.datasets[index].data.push(value);
        });

        if (chart.data.labels.length > 20) {
            chart.data.labels.shift();
            chart.data.datasets.forEach(dataset => dataset.data.shift());
        }

        chart.update();
    }

    updateDeviceList(devices) {
        const tbody = document.getElementById('deviceList');
        if (!tbody) return;

        tbody.innerHTML = devices.map(device => `
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="health-indicator health-${this.getHealthClass(device.health)}"></div>
                        ${device.name}
                    </div>
                </td>
                <td>${device.group || '-'}</td>
                <td>
                    <span class="badge bg-${this.getStatusColor(device.status)}">
                        ${device.status}
                    </span>
                </td>
                <td>${device.health}%</td>
                <td>${device.cpu_usage.toFixed(1)}%</td>
                <td>${device.memory_usage.toFixed(1)}%</td>
                <td>${device.disk_usage.toFixed(1)}%</td>
                <td>${this.formatLastSeen(device.last_seen)}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="monitoringDashboard.viewDeviceDetails(${device.id})">
                            <i class="fas fa-info-circle"></i>
                        </button>
                        <button class="btn btn-outline-secondary" onclick="monitoringDashboard.showDeviceSettings(${device.id})">
                            <i class="fas fa-cog"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    checkThresholds(stats) {
        if (stats.cpu_usage > this.settings.thresholds.cpu.critical) {
            this.showAlert('danger', `Critical CPU usage: ${stats.cpu_usage}%`);
        } else if (stats.cpu_usage > this.settings.thresholds.cpu.warning) {
            this.showAlert('warning', `High CPU usage: ${stats.cpu_usage}%`);
        }

        if (stats.memory_usage > this.settings.thresholds.memory.critical) {
            this.showAlert('danger', `Critical memory usage: ${stats.memory_usage}%`);
        } else if (stats.memory_usage > this.settings.thresholds.memory.warning) {
            this.showAlert('warning', `High memory usage: ${stats.memory_usage}%`);
        }
    }

    showAlert(type, message) {
        const toast = new bootstrap.Toast(document.getElementById('alertToast'));
        const toastBody = document.querySelector('#alertToast .toast-body');
        if (toastBody) {
            toastBody.textContent = message;
            toastBody.className = `toast-body text-${type}`;
            toast.show();
        }
    }

    getHealthClass(score) {
        if (score >= 80) return 'good';
        if (score >= 60) return 'warning';
        return 'critical';
    }

    getStatusColor(status) {
        const colors = {
            online: 'success',
            offline: 'danger',
            warning: 'warning',
            maintenance: 'info'
        };
        return colors[status] || 'secondary';
    }

    formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        return `${days}d ${hours}h`;
    }

    formatLastSeen(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = Math.floor((now - date) / 1000);

        if (diff < 60) return 'Just now';
        if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
        if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
        return date.toLocaleDateString();
    }

    startMonitoring() {
        this.updateMetrics();
        //The interval is now managed by the websocket, so we remove the interval here
    }

    cleanup() {
        this.socket?.disconnect();
    }

    async acknowledgeAlert(alertId) {
        try {
            const response = await fetch(`/api/monitoring/alerts/${alertId}/acknowledge`, {
                method: 'POST'
            });

            if (!response.ok) {
                throw new Error('Failed to acknowledge alert');
            }

            // Refresh alerts
            this.updateMetrics();

        } catch (error) {
            console.error('Error acknowledging alert:', error);
            alert('Failed to acknowledge alert. Please try again.');
        }
    }

    saveSettings() {
        const form = document.getElementById('dashboardSettings');
        const formData = new FormData(form);

        this.settings.updateInterval = parseInt(formData.get('updateInterval'));
        this.settings.chartType = formData.get('chartType');
        this.settings.thresholds = {
            cpu: {
                warning: parseInt(formData.get('cpuWarning')),
                critical: parseInt(formData.get('cpuCritical'))
            },
            memory: {
                warning: parseInt(formData.get('memoryWarning')),
                critical: parseInt(formData.get('memoryCritical'))
            },
            disk: {
                warning: parseInt(formData.get('diskWarning')),
                critical: parseInt(formData.get('diskCritical'))
            }
        };

        // Reinitialize charts with new type
        this.initializeCharts();

        // Restart monitoring with new interval
        this.startMonitoring();

        // Save settings to server
        this.saveSettingsToServer();
    }

    async saveSettingsToServer() {
        try {
            const response = await fetch('/api/monitoring/settings', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.settings)
            });

            if (!response.ok) {
                throw new Error('Failed to save settings');
            }

            // Show success message
            const toast = new bootstrap.Toast(document.getElementById('settingsToast'));
            document.querySelector('#settingsToast .toast-body').textContent =
                'Settings saved successfully';
            toast.show();

        } catch (error) {
            console.error('Error saving settings:', error);
            alert('Failed to save settings. Please try again.');
        }
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    getAlertColor(severity) {
        switch (severity.toLowerCase()) {
            case 'critical': return 'danger';
            case 'warning': return 'warning';
            case 'info': return 'info';
            default: return 'secondary';
        }
    }

    updateDeviceStatus(status) {
        const statusElement = document.getElementById('deviceStatus');
        if (!statusElement) return;

        let statusHtml = `
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Device Status</h5>
                    <div class="status-indicator ${status.is_online ? 'online' : 'offline'}">
                        <span class="status-dot"></span>
                        <span class="status-text">${status.is_online ? 'Online' : 'Offline'}</span>
                    </div>

                    <div class="mt-3">
                        <p class="mb-2">
                            <strong>Last Seen:</strong>
                            ${new Date(status.last_seen).toLocaleString()}
                        </p>
                        ${!status.is_online ? `
                            <p class="mb-2">
                                <strong>Last Online:</strong>
                                ${new Date(status.last_online).toLocaleString()}
                            </p>
                            <p class="mb-2">
                                <strong>Offline Reason:</strong>
                                ${status.offline_reason || 'Unknown'}
                            </p>
                        ` : ''}
                        <p class="mb-2">
                            <strong>Uptime (30 days):</strong>
                            ${status.uptime_percentage.toFixed(2)}%
                        </p>
                        <div class="progress">
                            <div class="progress-bar ${this.getUptimeClass(status.uptime_percentage)}"
                                 role="progressbar"
                                 style="width: ${status.uptime_percentage}%">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Connection History</h5>
                    <div class="connection-timeline">
                        ${this.renderConnectionHistory(status.connection_history)}
                    </div>
                </div>
            </div>
        `;

        statusElement.innerHTML = statusHtml;
    }

    getUptimeClass(percentage) {
        if (percentage >= 99) return 'bg-success';
        if (percentage >= 95) return 'bg-info';
        if (percentage >= 90) return 'bg-warning';
        return 'bg-danger';
    }

    renderConnectionHistory(history) {
        if (!history || !history.length) {
            return '<p class="text-muted">No connection history available</p>';
        }

        return `
            <div class="timeline">
                ${history.reverse().map(event => `
                    <div class="timeline-item">
                        <div class="timeline-marker ${event.status === 'online' ? 'online' : 'offline'}"></div>
                        <div class="timeline-content">
                            <p class="mb-0">
                                <strong>${event.status === 'online' ? 'Connected' : 'Disconnected'}</strong>
                            </p>
                            <small class="text-muted">
                                ${new Date(event.timestamp).toLocaleString()}
                                ${event.reason ? `<br>${event.reason}` : ''}
                            </small>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    updateAlerts(alerts) {
        const tbody = document.getElementById('activeAlerts');
        if (!tbody) return;

        tbody.innerHTML = alerts.map(alert => `
            <tr class="alert-${alert.severity}">
                <td>
                    <span class="badge bg-${this.getAlertColor(alert.severity)}">
                        ${alert.severity.toUpperCase()}
                    </span>
                </td>
                <td>${alert.message}</td>
                <td>${alert.source}</td>
                <td>${new Date(alert.triggered_at).toLocaleString()}</td>
                <td>
                    <button class="btn btn-sm btn-outline-secondary acknowledge-alert"
                            data-alert-id="${alert.id}">
                        Acknowledge
                    </button>
                </td>
            </tr>
        `).join('');
    }


    // Added functions from edited code
    filterDevices(query) {
        //Implementation for filtering devices
    }

    filterByGroup(group) {
        //Implementation for filtering by group
    }

    filterByStatus(status) {
        //Implementation for filtering by status
    }

    sortDevices(sortBy) {
        //Implementation for sorting devices
    }

    saveAlertSettings() {
        //Implementation for saving alert settings
    }

    handleDeviceAlert(data) {
        //Implementation for handling device alerts
    }

    viewDeviceDetails(deviceId){
        //Implementation for viewing device details
    }

    showDeviceSettings(deviceId){
        //Implementation for showing device settings
    }
}

// Initialize dashboard when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.monitoringDashboard = new MonitoringDashboard();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    window.monitoringDashboard?.cleanup();
});