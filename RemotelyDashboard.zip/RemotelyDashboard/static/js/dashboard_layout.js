document.addEventListener('DOMContentLoaded', function() {
    let grid;
    let currentLayout;
    
    // Initialize GridStack
    const initGrid = () => {
        const gridElement = document.querySelector('.grid-stack');
        if (!gridElement) return;

        grid = GridStack.init({
            column: 12,
            row: 12,
            animate: true,
            draggable: {
                handle: '.widget-header'
            },
            resizable: {
                handles: 'e, se, s, sw, w'
            },
            float: true,
            margin: 10,
        });

        // Load saved layout if exists
        loadSavedLayout();
        
        // Add event listeners for layout changes
        grid.on('change', saveLayout);
    };

    // Save layout to server
    const saveLayout = () => {
        if (!grid) return;
        
        const items = grid.save();
        const layoutConfig = {
            widgets: items.map(item => ({
                id: item.id,
                x: item.x,
                y: item.y,
                w: item.w,
                h: item.h,
                type: item.type,
                config: item.config || {}
            }))
        };

        fetch('/api/dashboard/layout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                layout_config: layoutConfig,
                name: currentLayout || 'Default'
            })
        });
    };

    // Load saved layout from server
    const loadSavedLayout = async () => {
        try {
            const response = await fetch('/api/dashboard/layout');
            const data = await response.json();
            
            if (data.layout_config && data.layout_config.widgets) {
                currentLayout = data.name;
                grid.removeAll();
                
                data.layout_config.widgets.forEach(widget => {
                    addWidget(widget);
                });
            }
        } catch (error) {
            console.error('Error loading layout:', error);
        }
    };

    // Add new widget
    const addWidget = (widget) => {
        const widgetHtml = `
            <div class="grid-stack-item" gs-id="${widget.id}" gs-type="${widget.type}">
                <div class="grid-stack-item-content">
                    <div class="widget-header">
                        <h5>${widget.title || widget.type}</h5>
                        <div class="widget-controls">
                            <button class="btn btn-sm btn-outline-secondary widget-settings">
                                <i class="fas fa-cog"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger widget-remove">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="widget-body" id="widget-${widget.id}">
                        <!-- Widget content will be loaded here -->
                    </div>
                </div>
            </div>`;

        grid.addWidget({
            x: widget.x,
            y: widget.y,
            w: widget.w,
            h: widget.h,
            content: widgetHtml,
            id: widget.id,
            type: widget.type
        });

        // Initialize widget content
        initializeWidgetContent(widget);
    };

    // Initialize widget content based on type
    const initializeWidgetContent = (widget) => {
        const widgetBody = document.getElementById(`widget-${widget.id}`);
        if (!widgetBody) return;

        switch (widget.type) {
            case 'cpu':
                initCPUWidget(widgetBody, widget.config);
                break;
            case 'memory':
                initMemoryWidget(widgetBody, widget.config);
                break;
            case 'network':
                initNetworkWidget(widgetBody, widget.config);
                break;
            // Add more widget types here
        }
    };

    // Widget type initializers
    const initCPUWidget = (element, config) => {
        const canvas = document.createElement('canvas');
        element.appendChild(canvas);
        // Initialize CPU chart...
    };

    const initMemoryWidget = (element, config) => {
        const canvas = document.createElement('canvas');
        element.appendChild(canvas);
        // Initialize Memory chart...
    };

    const initNetworkWidget = (element, config) => {
        const canvas = document.createElement('canvas');
        element.appendChild(canvas);
        // Initialize Network chart...
    };

    // Event listeners for widget controls
    document.addEventListener('click', (e) => {
        if (e.target.closest('.widget-remove')) {
            const item = e.target.closest('.grid-stack-item');
            grid.removeWidget(item);
            saveLayout();
        } else if (e.target.closest('.widget-settings')) {
            const item = e.target.closest('.grid-stack-item');
            showWidgetSettings(item);
        }
    });

    // Initialize when DOM is ready
    initGrid();
});
