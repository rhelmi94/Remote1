class FileManager {
    constructor(deviceId) {
        this.deviceId = deviceId;
        this.currentPath = '/';
        this.selectedFiles = new Set();
        this.socket = null;
        this.initializeWebSocket();
        this.initializeUI();
        this.setupEventListeners();
        this.monitoringRules = new Map();
    }

    initializeWebSocket() {
        this.socket = io(`/file_manager/${this.deviceId}`);

        this.socket.on('connect', () => {
            console.log('Connected to file manager socket');
            this.loadDirectory(this.currentPath);
        });

        this.socket.on('file_list', (data) => {
            this.updateFileList(data.files);
        });

        this.socket.on('file_change', (data) => {
            this.handleFileChange(data);
        });

        this.socket.on('transfer_progress', (data) => {
            this.updateTransferProgress(data);
        });

        this.socket.on('error', (error) => {
            this.showError(error.message);
        });
    }

    handleFileChange(data) {
        // Handle real-time file changes
        const { type, path, details } = data;
        this.showNotification(`File ${type}: ${path}`);

        // Refresh the current directory if the changed file is in it
        if (path.startsWith(this.currentPath)) {
            this.loadDirectory(this.currentPath);
        }

        // Update monitoring logs
        this.updateMonitoringLogs(data);
    }

    updateTransferProgress(data) {
        const { id, filename, progress, speed, remaining } = data;
        const progressItem = document.querySelector(`#upload-${id}`);

        if (progressItem) {
            progressItem.querySelector('.progress-bar').style.width = `${progress}%`;
            progressItem.querySelector('.speed').textContent = this.formatBytes(speed) + '/s';
            progressItem.querySelector('.remaining').textContent = this.formatTime(remaining);
        }
    }

    async uploadFiles(files) {
        const modal = new bootstrap.Modal(document.getElementById('uploadProgressModal'));
        const progressList = document.getElementById('uploadProgressList');
        modal.show();

        for (const file of files) {
            const progressItem = document.createElement('div');
            progressItem.className = 'mb-3';
            progressItem.id = `upload-${Date.now()}-${file.name}`;
            progressItem.innerHTML = `
                <div class="d-flex justify-content-between mb-1">
                    <span>${file.name}</span>
                    <div>
                        <span class="speed">0 B/s</span>
                        <span class="remaining">--:--</span>
                    </div>
                </div>
                <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                </div>
            `;
            progressList.appendChild(progressItem);

            const formData = new FormData();
            formData.append('file', file);
            formData.append('path', this.currentPath);

            try {
                const response = await fetch(`/api/device/${this.deviceId}/files/upload`, {
                    method: 'POST',
                    body: formData
                });

                if (!response.ok) throw new Error('Upload failed');

                progressItem.classList.add('text-success');
                progressItem.querySelector('.progress-bar').classList.add('bg-success');

                // Add to transfer history
                this.updateTransferHistory({
                    type: 'upload',
                    filename: file.name,
                    size: file.size,
                    status: 'completed'
                });
            } catch (error) {
                progressItem.classList.add('text-danger');
                progressItem.querySelector('.progress-bar').classList.add('bg-danger');
                console.error('Upload error:', error);
                this.showError(`Failed to upload ${file.name}`);
            }
        }

        this.loadDirectory(this.currentPath);
    }

    async saveMonitoringRule() {
        const form = document.getElementById('monitoringRuleForm');
        const formData = new FormData(form);

        const rule = {
            path_pattern: formData.get('path_pattern'),
            watch_create: formData.get('watch_create') === 'on',
            watch_modify: formData.get('watch_modify') === 'on',
            watch_delete: formData.get('watch_delete') === 'on',
            watch_move: formData.get('watch_move') === 'on',
            alert_enabled: formData.get('alert_enabled') === 'on',
            alert_level: formData.get('alert_level')
        };

        try {
            const response = await fetch(`/api/device/${this.deviceId}/files/monitoring-rules`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(rule)
            });

            if (!response.ok) throw new Error('Failed to save monitoring rule');

            this.showAlert('success', 'Monitoring rule saved successfully');
            bootstrap.Modal.getInstance(document.getElementById('monitoringRulesModal')).hide();
            this.loadMonitoringRules();
        } catch (error) {
            console.error('Error saving monitoring rule:', error);
            this.showAlert('error', 'Failed to save monitoring rule');
        }
    }

    async loadVersionHistory(filePath) {
        try {
            const response = await fetch(`/api/device/${this.deviceId}/files/versions?path=${encodeURIComponent(filePath)}`);
            const history = await response.json();

            const tbody = document.getElementById('versionHistory');
            tbody.innerHTML = history.map(version => `
                <tr>
                    <td>${version.version}</td>
                    <td>${new Date(version.modified).toLocaleString()}</td>
                    <td>${this.formatBytes(version.size)}</td>
                    <td>${version.modified_by}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" onclick="fileManager.restoreVersion('${filePath}', ${version.version})">
                            Restore
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" onclick="fileManager.downloadVersion('${filePath}', ${version.version})">
                            Download
                        </button>
                    </td>
                </tr>
            `).join('');

            new bootstrap.Modal(document.getElementById('versionHistoryModal')).show();
        } catch (error) {
            console.error('Error loading version history:', error);
            this.showAlert('error', 'Failed to load version history');
        }
    }

    initializeUI() {
        // Initialize drag and drop
        const dropZone = document.getElementById('fileList');
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('drag-over');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('drag-over');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            const files = Array.from(e.dataTransfer.files);
            this.uploadFiles(files);
        });
    }

    setupEventListeners() {
        // File selection
        document.getElementById('fileList').addEventListener('click', (e) => {
            const row = e.target.closest('tr');
            if (!row) return;

            if (e.ctrlKey) {
                row.classList.toggle('selected');
                const fileId = row.dataset.fileId;
                if (row.classList.contains('selected')) {
                    this.selectedFiles.add(fileId);
                } else {
                    this.selectedFiles.delete(fileId);
                }
            } else {
                document.querySelectorAll('#fileList tr').forEach(r => r.classList.remove('selected'));
                row.classList.add('selected');
                this.selectedFiles.clear();
                this.selectedFiles.add(row.dataset.fileId);
            }

            this.updateActionButtons();
            this.previewFile(row.dataset.fileId);
        });

        // File operations
        document.getElementById('uploadFiles').addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.multiple = true;
            input.onchange = (e) => this.uploadFiles(Array.from(e.target.files));
            input.click();
        });

        document.getElementById('newFolder').addEventListener('click', () => {
            const modal = new bootstrap.Modal(document.getElementById('newFolderModal'));
            modal.show();
        });

        document.getElementById('createFolder').addEventListener('click', () => {
            const name = document.getElementById('folderName').value.trim();
            if (name) {
                this.createFolder(name);
                bootstrap.Modal.getInstance(document.getElementById('newFolderModal')).hide();
            }
        });

        document.getElementById('refresh').addEventListener('click', () => {
            this.loadDirectory(this.currentPath);
        });

        // File actions
        document.getElementById('download').addEventListener('click', () => {
            this.downloadSelectedFiles();
        });

        document.getElementById('delete').addEventListener('click', () => {
            if (confirm('Are you sure you want to delete the selected items?')) {
                this.deleteSelectedFiles();
            }
        });

        document.getElementById('rename').addEventListener('click', () => {
            if (this.selectedFiles.size === 1) {
                const fileId = Array.from(this.selectedFiles)[0];
                const fileName = document.querySelector(`tr[data-file-id="${fileId}"]`).dataset.fileName;
                document.getElementById('newName').value = fileName;
                const modal = new bootstrap.Modal(document.getElementById('renameModal'));
                modal.show();
            }
        });

        document.getElementById('confirmRename').addEventListener('click', () => {
            const newName = document.getElementById('newName').value.trim();
            if (newName) {
                const fileId = Array.from(this.selectedFiles)[0];
                this.renameFile(fileId, newName);
                bootstrap.Modal.getInstance(document.getElementById('renameModal')).hide();
            }
        });

        // Search functionality
        document.getElementById('fileSearch').addEventListener('input', (e) => {
            this.filterFiles(e.target.value);
        });
    }

    loadDirectory(path) {
        this.socket.emit('list_directory', { path });
        this.currentPath = path;
        this.updateBreadcrumb();
    }

    updateFileList(files) {
        const tbody = document.getElementById('fileList');
        tbody.innerHTML = '';

        files.forEach(file => {
            const row = document.createElement('tr');
            row.dataset.fileId = file.id;
            row.dataset.fileName = file.name;
            row.innerHTML = `
                <td>
                    <i class="fas ${file.type === 'directory' ? 'fa-folder' : 'fa-file'} me-2"></i>
                    ${file.name}
                </td>
                <td>${file.type === 'directory' ? '--' : this.formatSize(file.size)}</td>
                <td>${new Date(file.modified).toLocaleString()}</td>
                <td>${file.type}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        ${file.type === 'directory' ? `
                            <button class="btn btn-outline-secondary open-folder" title="Open">
                                <i class="fas fa-folder-open"></i>
                            </button>
                        ` : `
                            <button class="btn btn-outline-secondary preview-file" title="Preview">
                                <i class="fas fa-eye"></i>
                            </button>
                        `}
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });

        this.updateActionButtons();
    }


    async downloadSelectedFiles() {
        for (const fileId of this.selectedFiles) {
            const row = document.querySelector(`tr[data-file-id="${fileId}"]`);
            const fileName = row.dataset.fileName;

            try {
                const response = await fetch(`/api/device/${this.deviceId}/files/download?path=${encodeURIComponent(this.currentPath + '/' + fileName)}`);
                if (!response.ok) throw new Error('Download failed');

                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = fileName;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            } catch (error) {
                console.error('Download error:', error);
                this.showError(`Failed to download ${fileName}`);
            }
        }
    }

    deleteSelectedFiles() {
        const files = Array.from(this.selectedFiles).map(fileId => {
            const row = document.querySelector(`tr[data-file-id="${fileId}"]`);
            return row.dataset.fileName;
        });

        this.socket.emit('delete_files', {
            path: this.currentPath,
            files: files
        });
    }

    renameFile(fileId, newName) {
        const row = document.querySelector(`tr[data-file-id="${fileId}"]`);
        const oldName = row.dataset.fileName;

        this.socket.emit('rename_file', {
            path: this.currentPath,
            oldName: oldName,
            newName: newName
        });
    }

    createFolder(name) {
        this.socket.emit('create_folder', {
            path: this.currentPath,
            name: name
        });
    }

    updateBreadcrumb() {
        const breadcrumb = document.getElementById('pathBreadcrumb');
        breadcrumb.innerHTML = '<li class="breadcrumb-item"><a href="#" data-path="/">Root</a></li>';

        const parts = this.currentPath.split('/').filter(Boolean);
        let path = '';
        parts.forEach(part => {
            path += '/' + part;
            breadcrumb.innerHTML += `
                <li class="breadcrumb-item">
                    <a href="#" data-path="${path}">${part}</a>
                </li>
            `;
        });

        breadcrumb.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.loadDirectory(e.target.dataset.path);
            });
        });
    }

    updateActionButtons() {
        const hasSelection = this.selectedFiles.size > 0;
        const singleSelection = this.selectedFiles.size === 1;

        document.getElementById('download').disabled = !hasSelection;
        document.getElementById('delete').disabled = !hasSelection;
        document.getElementById('rename').disabled = !singleSelection;
        document.getElementById('move').disabled = !hasSelection;
        document.getElementById('copy').disabled = !hasSelection;
    }

    filterFiles(searchTerm) {
        const rows = document.querySelectorAll('#fileList tr');
        searchTerm = searchTerm.toLowerCase();

        rows.forEach(row => {
            const fileName = row.dataset.fileName.toLowerCase();
            row.style.display = fileName.includes(searchTerm) ? '' : 'none';
        });
    }

    async previewFile(fileId) {
        const row = document.querySelector(`tr[data-file-id="${fileId}"]`);
        const fileName = row.dataset.fileName;
        const preview = document.getElementById('filePreview');
        const properties = document.getElementById('fileProperties');

        try {
            const response = await fetch(`/api/device/${this.deviceId}/files/preview?path=${encodeURIComponent(this.currentPath + '/' + fileName)}`);
            if (!response.ok) throw new Error('Preview failed');

            const data = await response.json();
            preview.innerHTML = this.getPreviewContent(data);
            properties.innerHTML = this.getPropertiesContent(data);
        } catch (error) {
            console.error('Preview error:', error);
            preview.innerHTML = '<div class="text-center text-muted">Preview not available</div>';
        }
    }

    getPreviewContent(data) {
        if (data.type === 'image') {
            return `<img src="data:${data.mime};base64,${data.content}" class="img-fluid">`;
        } else if (data.type === 'text') {
            return `<pre><code>${data.content}</code></pre>`;
        } else {
            return `<div class="text-center text-muted">
                <i class="fas fa-file fa-3x mb-3"></i><br>
                Preview not available for this file type
            </div>`;
        }
    }

    getPropertiesContent(data) {
        return `
            <tr><td>Name:</td><td>${data.name}</td></tr>
            <tr><td>Size:</td><td>${this.formatSize(data.size)}</td></tr>
            <tr><td>Type:</td><td>${data.mime || data.type}</td></tr>
            <tr><td>Modified:</td><td>${new Date(data.modified).toLocaleString()}</td></tr>
            <tr><td>Permissions:</td><td>${data.permissions}</td></tr>
        `;
    }

    formatSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    showError(message) {
        // You can implement your preferred error notification method here
        alert(message);
    }

    handleOperationComplete(data) {
        if (data.success) {
            this.loadDirectory(this.currentPath);
        } else {
            this.showError(data.error || 'Operation failed');
        }
    }

    formatTime(seconds) {
        if (seconds < 60) return `${seconds}s`;
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }

    showNotification(message) {
        const toast = new bootstrap.Toast(document.getElementById('notificationToast'));
        document.querySelector('#notificationToast .toast-body').textContent = message;
        toast.show();
    }

    formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    updateMonitoringLogs(data) {
      //Implementation for updating monitoring logs -  This would typically involve appending to a log display area.  Details depend on the UI structure.
      console.log("Monitoring event:", data);
    }

    updateTransferHistory(data){
        //Implementation to update transfer history -  This would involve adding an entry to a history list or database.  Details depend on implementation.
        console.log("Transfer History:", data);
    }

    showAlert(type, message){
        //Implementation to show alerts, based on bootstrap or similar library.
        console.log("Alert:", type, message);
    }

    loadMonitoringRules(){
        //Implementation to load monitoring rules. This would involve a fetch call to retrieve the rules from the server
        console.log("Loading Monitoring Rules");
    }

    restoreVersion(filePath, version){
        //Implementation for restoring a file version
        console.log("Restoring Version:", filePath, version);
    }

    downloadVersion(filePath, version){
        //Implementation for downloading a file version
        console.log("Downloading Version:", filePath, version);
    }
}

// Initialize file manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const deviceId = new URLSearchParams(window.location.search).get('device_id');
    if (deviceId) {
        window.fileManager = new FileManager(deviceId);
    }
});