class BulkDeploymentManager {
    constructor() {
        this.initializeEventListeners();
        this.deploymentStats = {
            total: 0,
            success: 0,
            failed: 0,
            inProgress: 0
        };
        this.updateInterval = setInterval(() => this.refreshDeployments(), 30000);
        this.refreshDeployments();
    }

    initializeEventListeners() {
        // New deployment form
        document.getElementById('createDeployment')?.addEventListener('click', () => {
            this.createDeployment();
        });

        // Device selection
        document.getElementById('selectAllDevices')?.addEventListener('change', (e) => {
            document.querySelectorAll('.device-checkbox').forEach(checkbox => {
                checkbox.checked = e.target.checked;
            });
        });

        // Deployment type selection
        document.getElementById('deploymentType')?.addEventListener('change', (e) => {
            this.toggleDeploymentOptions(e.target.value);
        });

        // Schedule toggle
        document.getElementById('scheduleToggle')?.addEventListener('change', (e) => {
            const scheduleFields = document.getElementById('scheduleFields');
            if (scheduleFields) {
                scheduleFields.style.display = e.target.checked ? 'block' : 'none';
            }
        });
    }

    async createDeployment() {
        const form = document.getElementById('deploymentForm');
        if (!form) return;

        const formData = new FormData(form);
        const selectedDevices = Array.from(document.querySelectorAll('.device-checkbox:checked'))
            .map(cb => cb.value);

        if (selectedDevices.length === 0) {
            this.showAlert('error', 'Please select at least one device');
            return;
        }

        const deploymentData = {
            name: formData.get('name'),
            description: formData.get('description'),
            deployment_type: formData.get('type'),
            script_id: formData.get('type') === 'script' ? formData.get('script_id') : null,
            target_devices: selectedDevices,
            scheduled_time: this.getScheduledTime(formData),
            configuration: this.getDeploymentConfig(formData)
        };

        try {
            const response = await fetch('/api/deployments', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(deploymentData)
            });

            const result = await response.json();
            if (response.ok) {
                this.showAlert('success', 'Deployment created successfully');
                this.refreshDeployments();
                bootstrap.Modal.getInstance(document.getElementById('newDeploymentModal')).hide();
            } else {
                this.showAlert('error', result.error || 'Failed to create deployment');
            }
        } catch (error) {
            console.error('Error creating deployment:', error);
            this.showAlert('error', 'Failed to create deployment');
        }
    }

    getScheduledTime(formData) {
        if (!document.getElementById('scheduleToggle')?.checked) return null;
        const date = formData.get('schedule_date');
        const time = formData.get('schedule_time');
        return date && time ? `${date}T${time}` : null;
    }

    getDeploymentConfig(formData) {
        const type = formData.get('type');
        switch (type) {
            case 'windows_update':
                return {
                    categories: Array.from(document.querySelectorAll('input[name="update_category"]:checked'))
                        .map(cb => cb.value)
                };
            case 'software_install':
                return {
                    package_name: formData.get('package_name'),
                    version: formData.get('package_version'),
                    silent_install: formData.get('silent_install') === 'true'
                };
            default:
                return {};
        }
    }

    async refreshDeployments() {
        try {
            const response = await fetch('/api/deployments');
            const data = await response.json();

            this.updateDeploymentList(data.deployments);
            this.updateStatistics(data.stats);
            this.updateActivityFeed(data.recent_activity);
        } catch (error) {
            console.error('Error refreshing deployments:', error);
        }
    }

    updateDeploymentList(deployments) {
        const tbody = document.getElementById('deploymentList');
        if (!tbody) return;

        tbody.innerHTML = deployments.map(deployment => `
            <tr>
                <td>${deployment.name}</td>
                <td>
                    <span class="badge bg-${this.getTypeBadgeColor(deployment.deployment_type)}">
                        ${deployment.deployment_type}
                    </span>
                </td>
                <td>
                    <div class="progress">
                        <div class="progress-bar ${this.getProgressBarClass(deployment.status)}"
                             role="progressbar"
                             style="width: ${deployment.progress}%">
                            ${deployment.progress}%
                        </div>
                    </div>
                </td>
                <td>
                    <span class="badge bg-${this.getStatusBadgeColor(deployment.status)}">
                        ${deployment.status}
                    </span>
                </td>
                <td>${deployment.scheduled_time ? new Date(deployment.scheduled_time).toLocaleString() : 'Immediate'}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="deploymentManager.viewDetails(${deployment.id})">
                            <i class="fas fa-info-circle"></i>
                        </button>
                        ${deployment.status === 'pending' || deployment.status === 'in_progress' ? `
                            <button class="btn btn-outline-danger" onclick="deploymentManager.cancelDeployment(${deployment.id})">
                                <i class="fas fa-times"></i>
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }

    updateStatistics(stats) {
        document.getElementById('totalDeployments').textContent = stats.total;
        document.getElementById('successRate').textContent = `${stats.success_rate}%`;
        document.getElementById('inProgress').textContent = stats.in_progress;
        document.getElementById('failed').textContent = stats.failed;
    }

    updateActivityFeed(activities) {
        const feed = document.getElementById('activityFeed');
        if (!feed) return;

        feed.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon bg-${this.getActivityIconColor(activity.type)}">
                    <i class="fas ${this.getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-content">
                    <p class="mb-0">${activity.message}</p>
                    <small class="text-muted">${new Date(activity.timestamp).toLocaleString()}</small>
                </div>
            </div>
        `).join('');
    }

    async viewDetails(deploymentId) {
        try {
            const response = await fetch(`/api/deployments/${deploymentId}`);
            const deployment = await response.json();

            const detailsModal = document.getElementById('deploymentDetailsModal');
            const detailsContent = detailsModal.querySelector('.deployment-details');

            detailsContent.innerHTML = this.renderDeploymentDetails(deployment);
            new bootstrap.Modal(detailsModal).show();
        } catch (error) {
            console.error('Error fetching deployment details:', error);
            this.showAlert('error', 'Failed to load deployment details');
        }
    }

    renderDeploymentDetails(deployment) {
        return `
            <div class="row">
                <div class="col-md-6">
                    <h6>Deployment Information</h6>
                    <dl class="row">
                        <dt class="col-sm-4">Name</dt>
                        <dd class="col-sm-8">${deployment.name}</dd>

                        <dt class="col-sm-4">Type</dt>
                        <dd class="col-sm-8">${deployment.deployment_type}</dd>

                        <dt class="col-sm-4">Created</dt>
                        <dd class="col-sm-8">${new Date(deployment.created_at).toLocaleString()}</dd>

                        <dt class="col-sm-4">Status</dt>
                        <dd class="col-sm-8">
                            <span class="badge bg-${this.getStatusBadgeColor(deployment.status)}">
                                ${deployment.status}
                            </span>
                        </dd>
                    </dl>
                </div>
                <div class="col-md-6">
                    <h6>Progress</h6>
                    <div class="progress mb-3">
                        <div class="progress-bar ${this.getProgressBarClass(deployment.status)}"
                             role="progressbar"
                             style="width: ${deployment.progress}%">
                            ${deployment.progress}%
                        </div>
                    </div>
                    <p>
                        Success: ${deployment.success_count} / 
                        Failed: ${deployment.failure_count} / 
                        Total: ${deployment.target_devices.length}
                    </p>
                </div>
            </div>

            <h6 class="mt-4">Device Status</h6>
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Device</th>
                            <th>Status</th>
                            <th>Progress</th>
                            <th>Started</th>
                            <th>Completed</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${deployment.results.map(result => `
                            <tr>
                                <td>${result.device_name}</td>
                                <td>
                                    <span class="badge bg-${this.getStatusBadgeColor(result.status)}">
                                        ${result.status}
                                    </span>
                                </td>
                                <td>
                                    <div class="progress" style="height: 5px;">
                                        <div class="progress-bar ${this.getProgressBarClass(result.status)}"
                                             role="progressbar"
                                             style="width: ${result.progress}%">
                                        </div>
                                    </div>
                                </td>
                                <td>${result.started_at ? new Date(result.started_at).toLocaleString() : '-'}</td>
                                <td>${result.completed_at ? new Date(result.completed_at).toLocaleString() : '-'}</td>
                                <td>
                                    ${result.error_message ? `
                                        <button class="btn btn-sm btn-outline-danger"
                                                onclick="deploymentManager.showError('${result.error_message}')">
                                            <i class="fas fa-exclamation-circle"></i>
                                        </button>
                                    ` : ''}
                                    ${result.status === 'failed' ? `
                                        <button class="btn btn-sm btn-outline-primary"
                                                onclick="deploymentManager.retryDeployment(${deployment.id}, ${result.device_id})">
                                            <i class="fas fa-redo"></i>
                                        </button>
                                    ` : ''}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    showAlert(type, message) {
        const toast = new bootstrap.Toast(document.getElementById('alertToast'));
        const toastBody = document.querySelector('#alertToast .toast-body');
        if (toastBody) {
            toastBody.textContent = message;
            toast.show();
        }
    }

    getTypeBadgeColor(type) {
        const colors = {
            script: 'primary',
            windows_update: 'info',
            software_install: 'success',
            configuration: 'warning'
        };
        return colors[type] || 'secondary';
    }

    getStatusBadgeColor(status) {
        const colors = {
            pending: 'secondary',
            in_progress: 'primary',
            completed: 'success',
            failed: 'danger',
            cancelled: 'warning'
        };
        return colors[status] || 'secondary';
    }

    getProgressBarClass(status) {
        const classes = {
            pending: 'bg-secondary',
            in_progress: 'bg-primary progress-bar-striped progress-bar-animated',
            completed: 'bg-success',
            failed: 'bg-danger',
            cancelled: 'bg-warning'
        };
        return classes[status] || 'bg-secondary';
    }

    getActivityIconColor(type) {
        const colors = {
            create: 'primary',
            start: 'info',
            complete: 'success',
            fail: 'danger',
            cancel: 'warning'
        };
        return colors[type] || 'secondary';
    }

    getActivityIcon(type) {
        const icons = {
            create: 'fa-plus',
            start: 'fa-play',
            complete: 'fa-check',
            fail: 'fa-times',
            cancel: 'fa-ban'
        };
        return icons[type] || 'fa-info';
    }

    async cancelDeployment(deploymentId) {
        if (!confirm('Are you sure you want to cancel this deployment?')) return;
        try {
            const response = await fetch(`/api/deployments/${deploymentId}/cancel`, { method: 'POST' });
            if (response.ok) {
                this.showAlert('success', 'Deployment cancelled successfully');
                this.refreshDeployments();
            } else {
                const data = await response.json();
                this.showAlert('error', data.error || 'Failed to cancel deployment');
            }
        } catch (error) {
            console.error('Error canceling deployment:', error);
            this.showAlert('error', 'Failed to cancel deployment');
        }
    }


    toggleDeploymentOptions(type) {
        const scriptSelection = document.getElementById('scriptSelection');
        if (scriptSelection) {
            scriptSelection.classList.toggle('d-none', type === 'windows_update');
        }
    }

    showError(errorMessage) {
      alert(errorMessage);
    }

    async retryDeployment(deploymentId, deviceId) {
        //Implementation for retrying a failed deployment on a specific device.  
        //This would require a new API endpoint and needs to be fully implemented.
        alert(`Retry deployment ${deploymentId} on device ${deviceId} not yet implemented`);
    }


}

// Initialize deployment manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.deploymentManager = new BulkDeploymentManager();
});