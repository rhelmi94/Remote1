document.addEventListener('DOMContentLoaded', () => {
    let currentUserId = null;

    // Edit User
    document.querySelectorAll('.edit-user').forEach(button => {
        button.addEventListener('click', async (e) => {
            const row = e.target.closest('tr');
            currentUserId = row.dataset.userId;

            try {
                const response = await fetch(`/admin/users/${currentUserId}`);
                const userData = await response.json();

                document.getElementById('editUsername').value = userData.username;
                document.getElementById('editEmail').value = userData.email;
                document.getElementById('editPhone').value = userData.phone_number || '';
                document.getElementById('editIsAdmin').checked = userData.is_admin;
            } catch (error) {
                console.error('Error fetching user data:', error);
                alert('Failed to load user data');
            }
        });
    });

    // Save User Changes
    document.getElementById('saveUserChanges').addEventListener('click', async () => {
        if (!currentUserId) return;

        const userData = {
            username: document.getElementById('editUsername').value,
            email: document.getElementById('editEmail').value,
            phone_number: document.getElementById('editPhone').value,
            is_admin: document.getElementById('editIsAdmin').checked
        };

        try {
            const response = await fetch(`/admin/users/${currentUserId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            if (response.ok) {
                window.location.reload();
            } else {
                const data = await response.json();
                alert(data.error || 'Failed to update user');
            }
        } catch (error) {
            console.error('Error updating user:', error);
            alert('Failed to update user');
        }
    });

    // Reset Password
    document.querySelectorAll('.reset-password').forEach(button => {
        button.addEventListener('click', (e) => {
            const row = e.target.closest('tr');
            currentUserId = row.dataset.userId;
        });
    });

    document.getElementById('resetPasswordButton').addEventListener('click', async () => {
        if (!currentUserId) return;

        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }

        try {
            const response = await fetch(`/admin/users/reset-password/${currentUserId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ new_password: newPassword })
            });

            if (response.ok) {
                alert('Password reset successfully');
                document.getElementById('resetPasswordModal').querySelector('.btn-close').click();
                document.getElementById('resetPasswordForm').reset();
            } else {
                const data = await response.json();
                alert(data.error || 'Failed to reset password');
            }
        } catch (error) {
            console.error('Error resetting password:', error);
            alert('Failed to reset password');
        }
    });

    // Delete User
    document.querySelectorAll('.delete-user').forEach(button => {
        button.addEventListener('click', async (e) => {
            const row = e.target.closest('tr');
            const userId = row.dataset.userId;

            if (!confirm('Are you sure you want to delete this user?')) {
                return;
            }

            try {
                const response = await fetch(`/admin/users/${userId}`, {
                    method: 'DELETE'
                });

                if (response.ok) {
                    row.remove();
                } else {
                    const data = await response.json();
                    alert(data.error || 'Failed to delete user');
                }
            } catch (error) {
                console.error('Error deleting user:', error);
                alert('Failed to delete user');
            }
        });
    });
});
