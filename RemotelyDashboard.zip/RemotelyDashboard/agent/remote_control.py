import cv2
import numpy as np
import pyautogui
import threading
import base64
import win32gui
import win32con
import win32api
import logging
from PIL import Image
from io import BytesIO

logger = logging.getLogger('RemoteControl')

class RemoteControl:
    def __init__(self, socket):
        self.socket = socket
        self.running = False
        self.capture_thread = None
        self.session_id = None
        self.quality = 70
        self.frame_rate = 30
        self.scale_factor = 1.0

        # Initialize PyAutoGUI settings
        pyautogui.FAILSAFE = False
        self.screen_width, self.screen_height = pyautogui.size()

    def start_session(self, session_id):
        """Start a remote control session"""
        self.session_id = session_id
        self.running = True
        
        # Setup socket event handlers
        self.setup_socket_events()
        
        # Start screen capture thread
        self.capture_thread = threading.Thread(target=self.capture_screen_loop)
        self.capture_thread.start()
        
        logger.info(f"Started remote control session: {session_id}")

    def stop_session(self):
        """Stop the remote control session"""
        self.running = False
        if self.capture_thread:
            self.capture_thread.join()
        logger.info(f"Stopped remote control session: {self.session_id}")

    def setup_socket_events(self):
        """Setup socket event handlers for remote control"""
        @self.socket.on('mouse_event')
        def on_mouse_event(data):
            try:
                event_type = data.get('type')
                x = int(data.get('x') * self.screen_width)
                y = int(data.get('y') * self.screen_height)

                if event_type == 'move':
                    win32api.SetCursorPos((x, y))
                elif event_type == 'click':
                    win32api.SetCursorPos((x, y))
                    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, x, y, 0, 0)
                    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, x, y, 0, 0)
                elif event_type == 'rightclick':
                    win32api.SetCursorPos((x, y))
                    win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTDOWN, x, y, 0, 0)
                    win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTUP, x, y, 0, 0)
            except Exception as e:
                logger.error(f"Mouse event error: {str(e)}")

        @self.socket.on('keyboard_event')
        def on_keyboard_event(data):
            try:
                if data.get('type') == 'keypress':
                    key = data.get('key')
                    pyautogui.press(key)
                elif data.get('type') == 'keydown':
                    key = data.get('key')
                    pyautogui.keyDown(key)
                elif data.get('type') == 'keyup':
                    key = data.get('key')
                    pyautogui.keyUp(key)
            except Exception as e:
                logger.error(f"Keyboard event error: {str(e)}")

        @self.socket.on('quality_update')
        def on_quality_update(data):
            self.quality = data.get('quality', 70)
            self.frame_rate = data.get('frame_rate', 30)
            self.scale_factor = data.get('scale_factor', 1.0)

    def capture_screen_loop(self):
        """Continuously capture and send screen updates"""
        while self.running:
            try:
                # Capture screen
                screen = pyautogui.screenshot()
                
                # Resize if needed
                if self.scale_factor != 1.0:
                    new_size = (
                        int(screen.width * self.scale_factor),
                        int(screen.height * self.scale_factor)
                    )
                    screen = screen.resize(new_size, Image.LANCZOS)

                # Convert to JPEG
                buffer = BytesIO()
                screen.save(buffer, format='JPEG', quality=self.quality)
                image_data = base64.b64encode(buffer.getvalue()).decode()

                # Send frame
                self.socket.emit('screen_frame', {
                    'session_id': self.session_id,
                    'image': image_data,
                    'width': screen.width,
                    'height': screen.height,
                    'timestamp': time.time()
                })

                # Control frame rate
                time.sleep(1 / self.frame_rate)

            except Exception as e:
                logger.error(f"Screen capture error: {str(e)}")
                time.sleep(1)  # Wait before retrying on error
