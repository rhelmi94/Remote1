import os
import sys
import time
import json
import psutil
import logging
import win32serviceutil
import win32service
import win32event
import servicemanager
import socket
import requests
import socketio
from pathlib import Path
from datetime import datetime

# Configure logging
logging.basicConfig(
    filename='rmm_agent.log',
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('RMMAgent')

class RMMAgent(win32serviceutil.ServiceFramework):
    _svc_name_ = "RMMAgent"
    _svc_display_name_ = "Remote Management and Monitoring Agent"
    _svc_description_ = "Provides remote management and monitoring capabilities"

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.socket = None
        self.config = self.load_config()
        
    def load_config(self):
        """Load agent configuration from file"""
        config_path = Path(os.environ.get('PROGRAMDATA')) / 'RMMAgent' / 'config.json'
        if config_path.exists():
            with open(config_path) as f:
                return json.load(f)
        return {}

    def SvcStop(self):
        """Stop the service"""
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        if self.socket:
            self.socket.disconnect()

    def SvcDoRun(self):
        """Run the service"""
        try:
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, '')
            )
            self.main()
        except Exception as e:
            logger.error(f"Service error: {str(e)}")
            servicemanager.LogErrorMsg(f"Service error: {str(e)}")

    def main(self):
        """Main service loop"""
        try:
            # Initialize SocketIO connection
            self.socket = socketio.Client()
            self.setup_socket_events()
            self.connect_to_server()

            # Main loop
            while True:
                if win32event.WaitForSingleObject(self.stop_event, 1000) == win32event.WAIT_OBJECT_0:
                    break
                try:
                    self.collect_and_send_metrics()
                except Exception as e:
                    logger.error(f"Error collecting metrics: {str(e)}")
                time.sleep(60)  # Wait for 60 seconds before next collection

        except Exception as e:
            logger.error(f"Main loop error: {str(e)}")
        finally:
            if self.socket:
                self.socket.disconnect()

    def setup_socket_events(self):
        """Setup SocketIO event handlers"""
        @self.socket.on('connect')
        def on_connect():
            logger.info("Connected to RMM server")
            self.socket.emit('agent_register', {
                'license_key': self.config.get('license_key'),
                'hostname': socket.gethostname(),
                'ip_address': socket.gethostbyname(socket.gethostname())
            })

        @self.socket.on('disconnect')
        def on_disconnect():
            logger.info("Disconnected from RMM server")

        @self.socket.on('remote_control_request')
        def on_remote_control(data):
            """Handle remote control requests"""
            try:
                # Initialize remote control session
                from remote_control import RemoteControl
                remote = RemoteControl(self.socket)
                remote.start_session(data['session_id'])
            except Exception as e:
                logger.error(f"Remote control error: {str(e)}")

    def connect_to_server(self):
        """Connect to the RMM server"""
        server_url = self.config.get('server_url', 'http://localhost:5000')
        try:
            self.socket.connect(server_url)
        except Exception as e:
            logger.error(f"Failed to connect to server: {str(e)}")

    def collect_and_send_metrics(self):
        """Collect and send system metrics"""
        try:
            metrics = {
                'timestamp': datetime.utcnow().isoformat(),
                'cpu_percent': psutil.cpu_percent(interval=1),
                'memory_percent': psutil.virtual_memory().percent,
                'disk_usage': psutil.disk_usage('/').percent,
                'network': self.get_network_stats(),
                'process_count': len(psutil.pids()),
                'boot_time': psutil.boot_time()
            }
            self.socket.emit('system_metrics', metrics)
        except Exception as e:
            logger.error(f"Error collecting metrics: {str(e)}")

    def get_network_stats(self):
        """Get network statistics"""
        net_io = psutil.net_io_counters()
        return {
            'bytes_sent': net_io.bytes_sent,
            'bytes_recv': net_io.bytes_recv,
            'packets_sent': net_io.packets_sent,
            'packets_recv': net_io.packets_recv
        }

if __name__ == '__main__':
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(RMMAgent)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(RMMAgent)
