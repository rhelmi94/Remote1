import cv2
import numpy as np
from io import BytesIO
import base64
import time
import threading
import json
import logging
import pyautogui
from PIL import Image

class RemoteDesktopAgent:
    def __init__(self, quality=70, fps=30):
        self.quality = quality
        self.fps = fps
        self.running = False
        self.stream_thread = None
        self.screen_size = pyautogui.size()
        self.logger = logging.getLogger(__name__)

        # Configure PyAutoGUI
        pyautogui.FAILSAFE = False
        pyautogui.PAUSE = 0.1

    def capture_screen(self):
        """Capture screen and encode to base64 JPEG"""
        try:
            # Capture screen using pyautogui
            screenshot = pyautogui.screenshot()

            # Convert to JPEG and encode to base64
            buffered = BytesIO()
            screenshot.save(buffered, format="JPEG", quality=self.quality)
            img_str = base64.b64encode(buffered.getvalue()).decode()

            return {
                'image': img_str,
                'width': self.screen_size[0],
                'height': self.screen_size[1]
            }
        except Exception as e:
            self.logger.error(f"Screen capture error: {str(e)}")
            return None

    def handle_mouse_event(self, event_data):
        """Handle mouse events"""
        try:
            x = event_data.get('x')
            y = event_data.get('y')
            event_type = event_data.get('type')

            if None in (x, y, event_type):
                return

            if event_type == 'move':
                pyautogui.moveTo(x, y)
            elif event_type == 'click':
                pyautogui.click(x, y)
            elif event_type == 'double_click':
                pyautogui.doubleClick(x, y)
            elif event_type == 'right_click':
                pyautogui.rightClick(x, y)

        except Exception as e:
            self.logger.error(f"Mouse event error: {str(e)}")

    def handle_keyboard_event(self, event_data):
        """Handle keyboard events"""
        try:
            key = event_data.get('key')
            if key:
                pyautogui.press(key)
        except Exception as e:
            self.logger.error(f"Keyboard event error: {str(e)}")

    def start_streaming(self, callback):
        """Start screen streaming"""
        self.running = True

        def stream():
            while self.running:
                try:
                    frame_data = self.capture_screen()
                    if frame_data:
                        callback(frame_data)
                    time.sleep(1.0 / self.fps)
                except Exception as e:
                    self.logger.error(f"Streaming error: {str(e)}")
                    break

        self.stream_thread = threading.Thread(target=stream)
        self.stream_thread.start()

    def stop_streaming(self):
        """Stop screen streaming"""
        self.running = False
        if self.stream_thread:
            self.stream_thread.join()