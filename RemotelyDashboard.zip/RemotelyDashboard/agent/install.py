import os
import sys
import platform
import argparse
import subprocess
import shutil
import json
from pathlib import Path

def create_config(install_dir, server_url, device_id=None):
    """Create agent configuration file"""
    config = {
        'server_url': server_url,
        'device_id': device_id,
        'log_level': 'INFO',
        'screenshot_quality': 70,
        'fps': 30,
        'enabled_features': ['remote_desktop', 'system_monitor']
    }

    config_path = os.path.join(install_dir, 'config.json')
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)
    return config_path

def create_windows_service():
    """Create Windows service"""
    service_path = os.path.abspath("agent/remote_agent.py")
    python_exe = sys.executable

    # Create batch file to run the agent
    with open("run_agent.bat", "w") as f:
        f.write(f'@echo off\n"{python_exe}" "{service_path}" %*')

    # Install service
    subprocess.run([
        "sc", "create", "RemoteSystemAgent",
        "binPath=", os.path.abspath("run_agent.bat"),
        "start=", "auto",
        "DisplayName=", "Remote System Management Agent"
    ])

def create_linux_service():
    """Create Linux systemd service"""
    service_path = os.path.abspath("agent/remote_agent.py")
    python_exe = sys.executable

    service_content = f"""[Unit]
Description=Remote System Management Agent
After=network.target

[Service]
Type=simple
User={os.getenv('USER')}
WorkingDirectory={os.getcwd()}
ExecStart={python_exe} {service_path}
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
"""

    service_file = "/etc/systemd/system/remote-agent.service"
    with open(service_file, "w") as f:
        f.write(service_content)

    # Enable service
    subprocess.run(["systemctl", "daemon-reload"])
    subprocess.run(["systemctl", "enable", "remote-agent"])

def install_agent(server_url, device_id=None):
    """Install the remote management agent"""
    try:
        # Create installation directory
        install_dir = "/opt/remote-agent" if platform.system() != "Windows" else "C:\\Program Files\\RemoteAgent"
        os.makedirs(install_dir, exist_ok=True)

        # Create configuration
        config_path = create_config(install_dir, server_url, device_id)
        print(f"Created configuration at: {config_path}")

        # Copy agent files
        agent_files = [
            "agent/remote_agent.py",
            "agent/remote_desktop.py"
        ]
        for file in agent_files:
            shutil.copy2(file, install_dir)
            print(f"Copied {file} to {install_dir}")

        # Create service based on platform
        if platform.system() == "Windows":
            create_windows_service()
            print("Created Windows service")
        else:
            create_linux_service()
            print("Created Linux service")

        print("\nAgent installed successfully!")
        print(f"Configuration file: {config_path}")
        print("Use system service manager to start/stop the agent")
        return True

    except Exception as e:
        print(f"Error installing agent: {e}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Install Remote Management Agent")
    parser.add_argument("server_url", help="URL of the management server")
    parser.add_argument("--device-id", help="Optional device ID for existing devices")

    args = parser.parse_args()
    install_agent(args.server_url, args.device_id)