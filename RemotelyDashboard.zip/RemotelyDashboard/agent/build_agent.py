"""
Script to build the agent executable using PyInstaller
"""
import subprocess
import sys
import os
import logging

# Set up detailed logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def build_agent():
    """Build the agent executable"""
    try:
        # Ensure we're in the agent directory
        agent_dir = os.path.dirname(os.path.abspath(__file__))
        os.chdir(agent_dir)
        logger.info(f"Working directory: {os.getcwd()}")

        # Create dist directory
        dist_path = os.path.join(agent_dir, 'dist')
        os.makedirs(dist_path, exist_ok=True)

        # First test if we can build a minimal test agent
        logger.info("Testing PyInstaller with minimal test agent...")
        test_cmd = [
            sys.executable,
            '-m',
            'PyInstaller',
            '--onefile',
            '--log-level=DEBUG',
            '--workpath', os.path.join(agent_dir, 'build'),
            '--specpath', agent_dir,
            '--distpath', dist_path,
            'test_build.py'
        ]

        logger.info(f"Test command: {' '.join(test_cmd)}")
        test_result = subprocess.run(
            test_cmd,
            capture_output=True,
            text=True
        )

        logger.info(f"Test build stdout:\n{test_result.stdout}")
        if test_result.stderr:
            logger.error(f"Test build stderr:\n{test_result.stderr}")

        if test_result.returncode != 0:
            logger.error(f"Test build failed with code: {test_result.returncode}")
            return False

        logger.info("Test build completed successfully")
        return True

    except Exception as e:
        logger.error(f"Build failed with exception: {str(e)}", exc_info=True)
        return False

if __name__ == '__main__':
    success = build_agent()
    sys.exit(0 if success else 1)