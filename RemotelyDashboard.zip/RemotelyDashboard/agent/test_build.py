def main():
    with open("test.txt", "w") as f:
        f.write("Test build successful!")
    print("Test completed!")

if __name__ == "__main__":
    main()