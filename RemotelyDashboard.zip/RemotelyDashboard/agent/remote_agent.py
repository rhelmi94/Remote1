import os
import sys
import json
import time
import logging
import socketio
import threading
from remote_desktop import RemoteDesktopAgent

class RemoteManagementAgent:
    def __init__(self, config_path):
        self.load_config(config_path)
        self.setup_logging()
        self.sio = socketio.Client()
        self.remote_desktop = RemoteDesktopAgent()
        self.setup_socket_handlers()
        
    def load_config(self, config_path):
        """Load agent configuration"""
        try:
            with open(config_path) as f:
                self.config = json.load(f)
        except Exception as e:
            print(f"Error loading config: {e}")
            sys.exit(1)
            
    def setup_logging(self):
        """Configure logging"""
        logging.basicConfig(
            level=getattr(logging, self.config.get('log_level', 'INFO')),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler("/var/log/remote-agent.log"),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def setup_socket_handlers(self):
        """Setup Socket.IO event handlers"""
        @self.sio.on('connect')
        def on_connect():
            self.logger.info("Connected to management server")
            if self.config.get('device_id'):
                self.sio.emit('register_device', {
                    'device_id': self.config['device_id']
                })
                
        @self.sio.on('start_remote_desktop')
        def on_start_remote_desktop(data):
            def send_frame(frame_data):
                self.sio.emit('screen_frame', frame_data)
            self.remote_desktop.start_streaming(send_frame)
            
        @self.sio.on('stop_remote_desktop')
        def on_stop_remote_desktop(data):
            self.remote_desktop.stop_streaming()
            
        @self.sio.on('mouse_event')
        def on_mouse_event(data):
            self.remote_desktop.handle_mouse_event(data)
            
        @self.sio.on('keyboard_event')
        def on_keyboard_event(data):
            self.remote_desktop.handle_keyboard_event(data)
            
    def run(self):
        """Start the agent"""
        try:
            while True:
                try:
                    if not self.sio.connected:
                        self.sio.connect(self.config['server_url'])
                    time.sleep(5)
                except Exception as e:
                    self.logger.error(f"Connection error: {e}")
                    time.sleep(10)
        except KeyboardInterrupt:
            self.logger.info("Stopping agent...")
            self.cleanup()
            
    def cleanup(self):
        """Cleanup resources"""
        if self.remote_desktop:
            self.remote_desktop.stop_streaming()
        if self.sio.connected:
            self.sio.disconnect()

if __name__ == "__main__":
    config_path = "/opt/remote-agent/config.json"
    if sys.platform == "win32":
        config_path = "C:\\Program Files\\RemoteAgent\\config.json"
        
    agent = RemoteManagementAgent(config_path)
    agent.run()
