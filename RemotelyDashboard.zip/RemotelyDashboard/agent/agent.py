import os
import sys
import json
import time
import psutil
import platform
import requests
from datetime import datetime
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger('RemoteAgent')

class SystemMonitorAgent:
    def __init__(self, server_url, device_id=None):
        self.server_url = server_url.rstrip('/')
        self.device_id = device_id
        self.platform_info = self._get_platform_info()

    def _get_platform_info(self):
        """Get detailed system information"""
        try:
            return {
                'platform': platform.system(),
                'os_version': platform.version(),
                'cpu_model': platform.processor(),
                'total_memory': psutil.virtual_memory().total,
                'total_storage': psutil.disk_usage('/').total,
                'agent_version': '1.0.0'
            }
        except Exception as e:
            logger.error(f"Error getting platform info: {e}")
            return {}

    def _get_system_metrics(self):
        """Collect current system metrics"""
        try:
            network = psutil.net_io_counters()
            return {
                'timestamp': datetime.utcnow().isoformat(),
                'cpu_percent': psutil.cpu_percent(interval=1),
                'memory_percent': psutil.virtual_memory().percent,
                'disk_percent': psutil.disk_usage('/').percent,
                'network': {
                    'bytes_sent': network.bytes_sent,
                    'bytes_recv': network.bytes_recv
                },
                'process_count': len(psutil.pids())
            }
        except Exception as e:
            logger.error(f"Error collecting metrics: {e}")
            return {}

    def register_device(self):
        """Register this device with the server"""
        try:
            response = requests.post(
                f"{self.server_url}/api/devices/register",
                json=self.platform_info
            )
            if response.status_code == 200:
                self.device_id = response.json().get('device_id')
                logger.info(f"Device registered successfully with ID: {self.device_id}")
                return True
            else:
                logger.error(f"Failed to register device: {response.text}")
                return False
        except Exception as e:
            logger.error(f"Error registering device: {e}")
            return False

    def send_metrics(self):
        """Send system metrics to the server"""
        if not self.device_id:
            return False

        try:
            metrics = self._get_system_metrics()
            metrics['device_id'] = self.device_id

            response = requests.post(
                f"{self.server_url}/api/metrics",
                json=metrics
            )

            if response.status_code == 200:
                logger.debug("Metrics sent successfully")
                return True
            else:
                logger.error(f"Failed to send metrics: {response.text}")
                return False
        except Exception as e:
            logger.error(f"Error sending metrics: {e}")
            return False

    def run(self, interval=60):
        """Main agent loop"""
        logger.info("Starting system monitor agent")

        if not self.device_id and not self.register_device():
            logger.error("Failed to register device")
            return

        while True:
            try:
                self.send_metrics()
                time.sleep(interval)
            except KeyboardInterrupt:
                logger.info("Agent stopped by user")
                break
            except Exception as e:
                logger.error(f"Error in agent loop: {e}")
                time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python agent.py <server_url> [device_id]")
        sys.exit(1)

    server_url = sys.argv[1]
    device_id = sys.argv[2] if len(sys.argv) > 2 else None

    agent = SystemMonitorAgent(server_url, device_id)
    agent.run()